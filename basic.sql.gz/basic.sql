-- MySQL dump 10.19  Distrib 10.3.31-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.3.31-MariaDB-1:10.3.31+maria~focal-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `config` text COLLATE utf8_unicode_ci NOT NULL,
  `icon` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `non_exclude_fields` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `explicit_allowdeny` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `custom_options` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagetypes_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_modify` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `groupMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `subgroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `availableWidgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  `ses_backuserid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES ('7eda3a009fbe43547cd4bb5030732568','[DISABLED]',1,1641562247,'a:5:{s:26:\"formProtectionSessionToken\";s:64:\"3f83df962ac2031538747cb7a5cd398d4b0908d0a435137cd26c8028727b38ce\";s:27:\"core.template.flashMessages\";N;s:26:\"extbase.flashmessages.tx__\";N;s:52:\"TYPO3\\CMS\\Recordlist\\Controller\\RecordListController\";a:1:{s:12:\"search_field\";s:0:\"\";}s:80:\"extbase.flashmessages.tx_extensionmanager_tools_extensionmanagerextensionmanager\";N;}',0);
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lang` varchar(6) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `disableIPlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `createdByAction` int(11) NOT NULL DEFAULT 0,
  `usergroup_cached_list` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `category_perms` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1631519035,1631519035,0,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$Vi9RL1VKc09VdmpUSmU2bg$b1iqsY/dy15RfY93M+IkoCkQ7ieQIaQag1kEXrcCP0k',1,'','','',NULL,0,'',NULL,'','a:19:{s:14:\"interfaceSetup\";s:7:\"backend\";s:10:\"moduleData\";a:11:{s:10:\"web_layout\";a:2:{s:8:\"function\";s:1:\"2\";s:8:\"language\";s:1:\"0\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:8:\"web_list\";a:0:{}s:9:\"clipboard\";a:4:{s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";}s:6:\"web_ts\";a:8:{s:8:\"function\";s:85:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateInformationModuleFunctionController\";s:19:\"constant_editor_cat\";s:7:\"content\";s:15:\"ts_browser_type\";s:5:\"setup\";s:16:\"ts_browser_const\";s:1:\"0\";s:19:\"ts_browser_fixedLgd\";s:1:\"1\";s:23:\"ts_browser_showComments\";s:1:\"1\";s:25:\"tsbrowser_depthKeys_const\";a:2:{s:4:\"page\";i:1;s:18:\"page.fluidtemplate\";i:1;}s:25:\"tsbrowser_depthKeys_setup\";a:3:{s:6:\"config\";i:1;s:25:\"config.pageTitleProviders\";i:1;s:38:\"config.pageTitleProviders.altPageTitle\";i:1;}}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"c312013d83c1a6ad7fec8b36a37ba3c8\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:1;s:3:\"pid\";i:6;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"c312013d83c1a6ad7fec8b36a37ba3c8\";}s:16:\"opendocs::recent\";a:8:{s:32:\"740cc03766d763f816353ab2d91dbbaf\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:30;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B30%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:30;s:3:\"pid\";i:7;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"150b37b6f1b2a96d278b1a4b9ef46625\";a:4:{i:0;s:21:\"Datenschutzerklärung\";i:1;a:6:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:18;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B18%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:18;s:3:\"pid\";i:29;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:4:{i:0;s:22:\"Virtuelles Kartenforum\";i:1;a:6:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"86205c5935270b8ee413592ec1b62292\";a:4:{i:0;s:12:\"NEUE WEBSITE\";i:1;a:6:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"c7268aa47ca65e00129bc8557cb27ed8\";a:4:{i:0;s:4:\"jung\";i:1;a:6:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:844;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:33:\"&edit%5Bfe_users%5D%5B844%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:844;s:3:\"pid\";i:8;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"e9a20afc307b62f043716cd08b1e4fb7\";a:4:{i:0;s:19:\"<em>[No title]</em>\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:25;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B25%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:25;s:3:\"pid\";i:5;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"8900c77103e2f451ea79f6f9dccf0b4b\";a:4:{i:0;s:17:\"Georeferenzierung\";i:1;a:6:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:20;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B20%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:20;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"20ed475662b97ac33d3aa853a74f9c9c\";a:4:{i:0;s:13:\"Inhaltsseiten\";i:1;a:6:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:8:\"web_info\";a:1:{s:8:\"function\";s:48:\"TYPO3\\CMS\\Belog\\Module\\BackendLogModuleBootstrap\";}s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:353:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":12:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:12:\"\0*\0timeFrame\";i:0;s:9:\"\0*\0action\";i:-1;s:14:\"\0*\0groupByPage\";b:0;s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";s:16:\"browse_links.php\";a:1:{s:10:\"expandPage\";s:1:\"0\";}s:13:\"system_config\";a:3:{s:4:\"tree\";s:3:\"tca\";s:11:\"regexSearch\";b:0;s:8:\"node_tca\";a:0:{}}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1631520427;s:15:\"moduleSessionID\";a:10:{s:10:\"web_layout\";s:40:\"ae9983a24b43069dbf252dd44fc15f0cb3df8d1d\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"e1569f7b41abc2c349f615dc5c878ae29dbfbd28\";s:8:\"web_list\";s:40:\"ae9983a24b43069dbf252dd44fc15f0cb3df8d1d\";s:9:\"clipboard\";s:40:\"cf346629eb1aeac89a04ee4eb36bab7760f8bc7a\";s:6:\"web_ts\";s:40:\"2ed3e0fcb4d9a0289091d1d60eb8bebfbe2415f9\";s:10:\"FormEngine\";s:40:\"e1569f7b41abc2c349f615dc5c878ae29dbfbd28\";s:16:\"opendocs::recent\";s:40:\"e1569f7b41abc2c349f615dc5c878ae29dbfbd28\";s:8:\"web_info\";s:40:\"cf346629eb1aeac89a04ee4eb36bab7760f8bc7a\";s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:40:\"aebc0e8cc9ce79d4ae8a10588516b8b806d7c509\";s:16:\"browse_links.php\";s:40:\"e1569f7b41abc2c349f615dc5c878ae29dbfbd28\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:3:{s:3:\"0_1\";s:1:\"1\";s:3:\"0_2\";s:1:\"1\";s:4:\"0_29\";s:1:\"1\";}}}}s:10:\"inlineView\";s:84:\"a:1:{s:4:\"site\";a:1:{i:1;a:1:{s:13:\"site_language\";a:2:{i:3;s:1:\"0\";i:4;s:1:\"1\";}}}}\";s:10:\"modulemenu\";s:2:\"{}\";s:17:\"systeminformation\";s:45:\"{\"system_BelogLog\":{\"lastAccess\":1638267276}}\";s:11:\"browseTrees\";a:1:{s:11:\"browsePages\";s:7:\"[[1,1]]\";}}',NULL,NULL,1,'',0,NULL,1641557195,0,NULL,0,NULL,''),(2,0,1631519038,1631519038,0,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$b2l6Z0pTODgweGJ5RmVFUQ$eLWsybpezWOnv7pz6SrMCDCVS5QnkbdQte/xwwywJvI',1,'','','',NULL,0,'',NULL,'','a:13:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:0:{}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1631519038;}',NULL,NULL,1,'',0,NULL,0,0,NULL,0,NULL,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache`
--

LOCK TABLES `cache_adminpanel_requestcache` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache_tags`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache_tags`
--

LOCK TABLES `cache_adminpanel_requestcache_tags` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pagesection`
--

DROP TABLE IF EXISTS `cache_pagesection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pagesection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pagesection`
--

LOCK TABLES `cache_pagesection` WRITE;
/*!40000 ALTER TABLE `cache_pagesection` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pagesection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pagesection_tags`
--

DROP TABLE IF EXISTS `cache_pagesection_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pagesection_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pagesection_tags`
--

LOCK TABLES `cache_pagesection_tags` WRITE;
/*!40000 ALTER TABLE `cache_pagesection_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pagesection_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subgroup` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
INSERT INTO `fe_groups` VALUES (1,8,1631521078,1631521078,1,0,0,'','0','vk2-admin','','2','',''),(2,8,1631521078,1631521078,1,0,0,'','0','vk2-user','','','','');
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ses_anonymous` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `usergroup` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(160) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `middle_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `telephone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `www` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_forgotHash` varchar(80) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB AUTO_INCREMENT=848 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
INSERT INTO `fe_users` VALUES (465,8,1637246879,1631521078,1,0,0,0,0,NULL,'0','jmendt','$argon2i$v=19$m=65536,t=16,p=1$SnUxQkNRbzlsZHNMRXpFbg$7ym+AA1Bw7v7rr5PDIlDyBF9gTGnbgU/ikJOolu6t+c','1,2','Jacob Mendt','','','','','','','Jacob.Mendt@slub-dresden.de','',NULL,'','','','','','','0','',1639736985,1639741968,'','1547111465|11e0b8bf1630fc8a0d36045bae7455c1'),(549,8,1631521078,1631521078,1,0,0,0,0,NULL,'0','gzimmermann','$1$oZnc4KvM$PeQ0ZRhqXStpmkqnWiZkb0','2,1','Georg Zimmermann','Georg','','Zimmermann','','','','georg.zimmermann@slub-dresden.de','',NULL,'','','','','','',NULL,'',1596526302,0,'',''),(739,8,1631521078,1631521078,1,0,0,0,0,NULL,'0','bigga','$argon2i$v=19$m=65536,t=16,p=1$VU40dW15enhmNjBqemREUQ$RRyJ6D71J0KIXadJ2qKR+rhYlkTt8h4ZzA9taQh+fco','2,1','','','','','','','','alexander.bigga@slub-dresden.de','',NULL,'','','','','','',NULL,'',1627414587,0,'','1596856254|468113582eeda386b93d3c04fd6dbfad788a01aa'),(843,8,1637247042,1637246995,1,0,0,0,0,'','0','test','$argon2i$v=19$m=65536,t=16,p=1$REJhb0hsQUF5Z05aUlppQw$EOSoG67CdbDu6wthZSNyXgX1nFRUJqghj6N3DgNsNYw','1,2','Test','Test','','Test','','','','','',NULL,'','','','','','','0','',1637247170,1637251476,'',''),(844,8,1638267139,1638267139,1,0,0,0,0,'','0','jung','$argon2i$v=19$m=65536,t=16,p=1$NkVwNFdnaVozaGNtdFFlNQ$ur/EsMtFmFoS/BAMXbAEGQ4362wobD1DY8Gi9MFcoIo','1,2','','','','','','','','','',NULL,'','','','','','',NULL,'',1641561174,1641561304,'','');
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `newUntil` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `fe_login_mode` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tsconfig_includes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `legacy_overlay_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `og_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `canonical_link` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `categories` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter_card` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `legacy_overlay` (`legacy_overlay_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1639673958,1631521078,1,0,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Startseite','/',1,'',1,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1639673958,'','',0,'','','Virtuelles Kartenforum',0,0,0,0,0,0,'pagets__map','pagets__default','EXT:slub_web_kartenforum/Configuration/TsConfig/Page/All.tsconfig',0,1,'',0,0,'','',0,'','',0,'',0,0.5,'',''),(2,1,1639674119,1631521078,1,1,0,0,0,'',2816,'',0,0,0,0,NULL,0,'a:17:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Inhaltsseiten','/inhaltsseiten',199,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,0,'','',0,'','','',0,0,0,0,0,0,'','','',0,2,'',0,0,'','',0,'','',0,'',0,0.5,'',''),(3,1,1639674102,1631521078,1,0,0,0,0,'',2044,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'FAQ','/faq',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1631521078,NULL,'',0,'','','',0,0,0,0,0,0,'','','',0,3,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(4,1,1639674105,1631521078,1,0,0,0,0,'',2300,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Kontakt','/kontakt',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1631521078,NULL,'',0,'','','',0,0,0,0,0,0,'','','',0,4,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(5,1,1639674068,1631521078,1,0,0,0,0,'',64,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Willkommen','/willkommen',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1639674068,NULL,'',0,'','','',0,0,0,0,0,0,'','','',0,5,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(6,1,1639674086,1631521078,1,0,0,0,0,'',608,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Login','/login',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1639674086,NULL,'',0,'','','',1,0,0,0,0,0,'pagets__default','','',0,6,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(7,1,1639674082,1631521078,1,0,0,0,0,'',352,'',0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,1,0,31,27,0,'Registrieren','/registrieren',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1639674082,'','',0,'','','',1,0,0,0,0,0,'','','',0,7,'',0,0,'','',0,'','',0,'',0,0.5,'',''),(8,1,1631521078,1631521078,1,0,0,0,0,'',2688,NULL,0,0,0,0,NULL,0,'a:1:{s:5:\"title\";N;}',0,0,0,0,0,0,0,1,0,31,31,0,'Nutzerdaten','/users',254,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,0,'','',0,'','','',0,0,0,0,0,0,'','','',0,8,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(9,1,1639674078,1631521078,1,0,0,0,0,'',96,'',0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Ranking','/ranking',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1631521078,'','',0,'','','',0,0,0,0,0,0,'','','',0,9,'',0,0,'','',0,'','',0,'',0,0.5,'',''),(11,1,1639674089,1631521078,1,0,0,0,0,'2',864,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'History','/history',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1638198925,NULL,'',0,'','','',1,0,0,0,0,0,'','','',0,11,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(16,2,1638198953,1631521078,1,1,0,0,0,'',512,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Profile Map','/profile-map',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',1,0,0,0,0,0,'pagets__extended','','',0,16,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(17,29,1639728047,1631521078,1,0,0,0,0,'',128,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Impressum','/impressum',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1631521078,NULL,'',0,'','','',0,0,0,0,0,0,'','','',0,17,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(18,29,1639728044,1631521078,1,0,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:17:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Datenschutzerklärung','/datenschutzerklaerung',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1631521078,NULL,'',0,'','','',0,0,0,0,0,0,'','','',0,18,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(19,1,1639674095,1631521078,1,0,0,0,0,'2',1648,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Unreferenzierte Karten','/unreferenzierte-karten',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1638198914,'','',0,'','','',1,0,0,0,0,0,'','','',0,19,'',0,0,'','',0,'','',0,'',0,0.5,'',''),(20,1,1639674092,1631521078,1,0,0,0,0,'2',1120,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Georeferenzierung','/georeferenzierung',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1639674092,NULL,'',0,'','','',1,0,0,0,0,0,'pagets__georeference','','',0,20,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(21,0,1637664143,1631521830,1,0,0,0,0,'',256,NULL,0,1,1,1,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:53:{s:7:\"doktype\";i:1;s:5:\"title\";s:22:\"Virtuelles Kartenforum\";s:4:\"slug\";s:1:\"/\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";s:0:\"\";s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";s:0:\"\";s:8:\"abstract\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:1;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:11:\"pagets__map\";s:25:\"backend_layout_next_level\";s:15:\"pagets__default\";s:17:\"tsconfig_includes\";s:65:\"EXT:slub_web_kartenforum/Configuration/TsConfig/Page/All.tsconfig\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"nav_hide\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:16:\"content_from_pid\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'Virtual Map Forum','/',1,'',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1631521842,NULL,'',0,'','','',0,0,0,0,0,0,'pagets__map','pagets__default','EXT:slub_web_kartenforum/Configuration/TsConfig/Page/All.tsconfig',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(22,1,1639674078,1631521982,1,0,0,0,0,'',96,NULL,0,1,9,9,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:38:{s:7:\"doktype\";i:1;s:5:\"title\";s:7:\"Ranking\";s:4:\"slug\";s:8:\"/ranking\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";s:0:\"\";s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";s:0:\"\";s:8:\"abstract\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'Ranking','/ranking',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1631521989,NULL,'',0,'','','',0,0,0,0,0,0,'','','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(23,1,1639674086,1631522016,1,0,0,0,0,'',608,NULL,0,1,6,6,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:53:{s:7:\"doktype\";i:1;s:5:\"title\";s:5:\"Login\";s:4:\"slug\";s:6:\"/login\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:15:\"pagets__default\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"nav_hide\";i:1;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:16:\"content_from_pid\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'Login','/login',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',1,0,0,0,0,0,'pagets__default','','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(24,1,1639674082,1631522031,1,0,0,0,0,'',352,NULL,0,1,7,7,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:38:{s:7:\"doktype\";i:1;s:5:\"title\";s:12:\"Registrieren\";s:4:\"slug\";s:13:\"/registrieren\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";s:0:\"\";s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";s:0:\"\";s:8:\"abstract\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'Register','/register',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',1,0,0,0,0,0,'','','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(25,1,1639674089,1631522050,1,0,0,0,0,'2',864,NULL,0,1,11,11,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:53:{s:7:\"doktype\";i:1;s:5:\"title\";s:7:\"History\";s:4:\"slug\";s:8:\"/history\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:1:\"2\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"nav_hide\";i:1;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:16:\"content_from_pid\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'History','/history',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',1,0,0,0,0,0,'','','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(26,1,1639674102,1631522070,1,0,0,0,0,'',2044,NULL,0,1,3,3,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:38:{s:7:\"doktype\";i:1;s:5:\"title\";s:3:\"FAQ\";s:4:\"slug\";s:4:\"/faq\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'FAQ','/faq',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(27,1,1637846438,1637846432,1,1,0,0,0,'',512,'',0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,1,0,31,27,0,'Evaluation','/evaluation',199,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(28,1,1639674099,1637846548,1,0,0,0,0,'1',1912,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Evaluation','/evaluation',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1639674099,'','',0,'','','',0,0,0,0,0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0,0.5,'',''),(29,1,1639728062,1639728040,1,0,0,0,0,'0',2639,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Meta','/meta',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(30,29,1639728625,1639728056,1,0,0,0,0,'',64,NULL,0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'404-Fehler','/404',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',1,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `module_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  KEY `uid_local_foreign` (`uid_local`,`uid_foreign`),
  KEY `uid_foreign_tablefield` (`uid_foreign`,`tablenames`(40),`fieldname`(3),`sorting_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection`
--

DROP TABLE IF EXISTS `sys_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'static',
  `table_name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection`
--

LOCK TABLES `sys_collection` WRITE;
/*!40000 ALTER TABLE `sys_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection_entries`
--

DROP TABLE IF EXISTS `sys_collection_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection_entries` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection_entries`
--

LOCK TABLES `sys_collection_entries` WRITE;
/*!40000 ALTER TABLE `sys_collection_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `folder_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mime_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `sha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1631521048,1631521048,0,1,'1',0,'/user_upload/_temp_/importexport/kartenforum__1_.xml','902ac0fe52056a04b22e59a461d1fffea69a7b1f','0795cf796b4fc959be0ec00b183c0f47609dd9a5','xml','text/xml','kartenforum__1_.xml','b452c5df8ee454e39a3584addd5dbb44c8b508a4',2375076,1631521048,1631521048);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1631521048,1631521048,1,0,0,NULL,0,'',0,0,0,0,0,0,0,1,NULL,0,0,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `task_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `checksum` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  `processing_url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `table_local` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `crop` varchar(4000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `driver` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1631521026,1631521026,0,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin/ (auto-created)','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `base` int(10) unsigned NOT NULL DEFAULT 0,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `history_data` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_language`
--

DROP TABLE IF EXISTS `sys_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_language` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flag` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `language_isocode` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_language`
--

LOCK TABLES `sys_language` WRITE;
/*!40000 ALTER TABLE `sys_language` DISABLE KEYS */;
INSERT INTO `sys_language` VALUES (1,0,1631521559,0,256,'English','gb','en');
/*!40000 ALTER TABLE `sys_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `log_data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `request_id` varchar(13) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `level` smallint(5) unsigned NOT NULL DEFAULT 0,
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `parent` (`pid`),
  KEY `errorcount` (`tstamp`,`error`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `content` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_redirect`
--

DROP TABLE IF EXISTS `sys_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_redirect` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdby` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `source_host` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `source_path` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_regexp` smallint(5) unsigned NOT NULL DEFAULT 0,
  `force_https` smallint(5) unsigned NOT NULL DEFAULT 0,
  `respect_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `keep_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `target` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `target_statuscode` int(11) NOT NULL DEFAULT 307,
  `hitcount` int(11) NOT NULL DEFAULT 0,
  `lasthiton` int(11) NOT NULL DEFAULT 0,
  `disable_hitcount` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_source` (`source_host`(80),`source_path`(80)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_redirect`
--

LOCK TABLES `sys_redirect` WRITE;
/*!40000 ALTER TABLE `sys_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flexpointer` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_key` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('00198bdc1f40f03ab1107d3118695498','fe_users',488,'usergroup','','','',0,0,0,'fe_groups',2,''),('004df995152064d9ecdcf6152234a10f','fe_users',346,'usergroup','','','',0,0,0,'fe_groups',2,''),('009c6ffd7247fe249958598fd216b052','fe_users',590,'usergroup','','','',0,0,0,'fe_groups',2,''),('00b9562971c7d912efd6ced296258456','fe_users',167,'usergroup','','','',0,0,0,'fe_groups',2,''),('00d7bf1fd8deb3bd181a267accd873ca','fe_users',75,'usergroup','','','',0,0,0,'fe_groups',2,''),('013fff1a931c749f3e780af391d09857','fe_users',645,'usergroup','','','',0,1,0,'fe_groups',2,''),('01a0a03af0a9dd9d1bd3c3abac60d167','fe_users',459,'usergroup','','','',0,0,0,'fe_groups',2,''),('01f22ed2864f166bf0621f47066cca22','fe_users',453,'usergroup','','','',0,0,0,'fe_groups',2,''),('0235ef84c8104b1aeee21705fafcc539','fe_users',330,'usergroup','','','',0,0,0,'fe_groups',2,''),('02a30d73bc7b97c98cccff74322fd607','fe_users',627,'usergroup','','','',0,0,0,'fe_groups',2,''),('0302ef57c0482427f6ba386e1efed761','fe_users',572,'usergroup','','','',0,0,0,'fe_groups',2,''),('032583a66710f009a3b5977d21644e62','fe_users',157,'usergroup','','','',0,0,0,'fe_groups',2,''),('03916479d42933fbafaef549e3af1cde','fe_users',44,'usergroup','','','',0,0,0,'fe_groups',2,''),('03d23356af047f619b57a06af38edf6e','fe_users',638,'usergroup','','','',0,0,0,'fe_groups',2,''),('03f6a7a42910f1a7d38969cc7adf5b8e','fe_users',313,'usergroup','','','',0,0,0,'fe_groups',2,''),('03fdcba54df8e2aab3280eb2ba0fb102','fe_users',806,'usergroup','','','',0,1,0,'fe_groups',2,''),('0402369a2ef4af9fef4ed6f1f4f1774d','fe_users',229,'usergroup','','','',0,0,0,'fe_groups',2,''),('046735e70b839cbf311a661809654675','fe_users',122,'usergroup','','','',0,0,0,'fe_groups',2,''),('046ac56e7dc54f085d050bb79f2d5729','fe_users',323,'usergroup','','','',0,0,0,'fe_groups',2,''),('048542abf4550ffcb7d778ea7f683558','fe_users',709,'usergroup','','','',0,1,0,'fe_groups',2,''),('04d3bde92bff40ba24bb1d0714498cf3','fe_users',290,'usergroup','','','',0,0,0,'fe_groups',2,''),('04e2295e284d02fe318a370ce50a1a62','fe_users',58,'usergroup','','','',0,0,0,'fe_groups',2,''),('0509e079c1fafb40e7aa3bc0813041fd','fe_users',549,'usergroup','','','',0,0,0,'fe_groups',2,''),('05344de050b0854696b44c37991863da','fe_users',717,'usergroup','','','',0,1,0,'fe_groups',2,''),('0537ed5dc7a3e5a160010694e554e8a6','fe_users',668,'usergroup','','','',0,1,0,'fe_groups',2,''),('05414a118ef58127be9593cf4de40b4a','fe_users',368,'usergroup','','','',0,0,0,'fe_groups',2,''),('054803e89a84c03f05cc8bfcc0c3bc59','fe_users',169,'usergroup','','','',0,0,0,'fe_groups',2,''),('0576e17385f3fb757eeba8cf566ca525','fe_users',133,'usergroup','','','',0,0,0,'fe_groups',2,''),('06138decb2bb4afd7052c277d860786e','fe_users',512,'usergroup','','','',0,0,0,'fe_groups',2,''),('069b08cbf4d472a01af51d6bb2e1bb16','fe_users',111,'usergroup','','','',0,0,0,'fe_groups',2,''),('0711dd8b9bf1011ffff87ad37352d1fb','fe_users',148,'usergroup','','','',0,0,0,'fe_groups',2,''),('0742f40f4d781d85dfba2b1d0654a6e6','fe_users',526,'usergroup','','','',0,0,0,'fe_groups',2,''),('07b18df9ac0289a6e2583443e465468b','fe_users',471,'usergroup','','','',0,0,0,'fe_groups',2,''),('07d9f2ed2338636fb90b28b1dd8f001a','fe_users',240,'usergroup','','','',0,0,0,'fe_groups',2,''),('07e7749bcefb05775f27b39f591e6ea3','fe_users',260,'usergroup','','','',0,0,0,'fe_groups',2,''),('0868ef17c8686572cdc6ffc5510f23c3','fe_users',630,'usergroup','','','',0,0,0,'fe_groups',2,''),('094107553d4f008d0a8c1b4e2af90d72','fe_users',166,'usergroup','','','',0,0,0,'fe_groups',2,''),('0988325055d6eca400c6b616e41b17a9','fe_users',749,'usergroup','','','',0,1,0,'fe_groups',2,''),('09d69cfa1dda7209e535578c398a7c60','fe_users',828,'usergroup','','','',0,1,0,'fe_groups',2,''),('0a0abf1ab0ba969ba620a1afb5aeac62','fe_users',114,'usergroup','','','',0,0,0,'fe_groups',2,''),('0a506325c1fd700e13820f9c9940890c','fe_users',456,'usergroup','','','',0,0,0,'fe_groups',2,''),('0aa8b7d19c794df2dfdf9ba8e4aa2ac9','fe_users',663,'usergroup','','','',0,1,0,'fe_groups',2,''),('0b901cc1c18bc78ff16ec6729e54db04','fe_users',823,'usergroup','','','',0,1,0,'fe_groups',2,''),('0b95a5893e0f93bd0d5998ec2b39629b','fe_users',677,'usergroup','','','',0,1,0,'fe_groups',2,''),('0baada616d25293264352ddcac4035a5','fe_users',201,'usergroup','','','',0,0,0,'fe_groups',2,''),('0c23403be78aac65644554af5267e46a','fe_users',573,'usergroup','','','',0,0,0,'fe_groups',2,''),('0c8065cb592502179cbc8b5a77400dc4','fe_users',432,'usergroup','','','',0,0,0,'fe_groups',2,''),('0cefa4265c778192ea44d0b7b7a0c5f9','fe_users',489,'usergroup','','','',0,0,0,'fe_groups',2,''),('0d19bc9157a5e686b19550d53d57ed08','fe_users',175,'usergroup','','','',0,0,0,'fe_groups',2,''),('0dad205f0339311f9a79589720ea3735','fe_users',700,'usergroup','','','',0,1,0,'fe_groups',2,''),('0db6381bc2e3e70e4186fcb7e59970e9','fe_users',275,'usergroup','','','',0,0,0,'fe_groups',2,''),('0e0f8011625e036b582036b2f63d0f23','fe_users',350,'usergroup','','','',0,0,0,'fe_groups',2,''),('0e2920230f3f8542635bf414bb7f497d','fe_users',491,'usergroup','','','',0,0,0,'fe_groups',2,''),('0e9d321e325780535e16014763bee787','fe_users',31,'usergroup','','','',0,0,0,'fe_groups',2,''),('0ea1c01a3e29ef5f2571e8707e673d08','fe_users',679,'usergroup','','','',0,1,0,'fe_groups',2,''),('0eb06e36d2c9195e5c58bb2982011f71','fe_users',455,'usergroup','','','',0,0,0,'fe_groups',2,''),('0f6c1c2b7cc6ba3054eae11427eb04f1','fe_users',741,'usergroup','','','',0,1,0,'fe_groups',2,''),('102f9a0ded70cd3eef856d2c30cc2b85','fe_users',365,'usergroup','','','',0,0,0,'fe_groups',2,''),('1077bce812778c3abca9cff9243e96f9','fe_users',403,'usergroup','','','',0,0,0,'fe_groups',2,''),('1091145b88a8bf9c77754a965206b1f1','fe_users',695,'usergroup','','','',0,1,0,'fe_groups',2,''),('10b9d20672bfbd46dfd4a57fb673c4a5','fe_users',779,'usergroup','','','',0,1,0,'fe_groups',2,''),('10fd2053c6d890550bf2c02f44009bca','fe_users',628,'usergroup','','','',0,0,0,'fe_groups',2,''),('1149f979b33cc4f18576a5d6d53f8e79','fe_users',121,'usergroup','','','',0,0,0,'fe_groups',2,''),('117ad537913456445814565b869fa9a7','fe_users',477,'usergroup','','','',0,0,0,'fe_groups',2,''),('11b30bbe2ec7bae8d8c302ba0d873141','fe_users',837,'usergroup','','','',0,1,0,'fe_groups',2,''),('127d9583a399f27cc361718c368d6123','fe_users',373,'usergroup','','','',0,0,0,'fe_groups',2,''),('129cca130770a91f50061721e1474907','fe_users',67,'usergroup','','','',0,0,0,'fe_groups',2,''),('12f68b615e83b8f9e18926e76ff97bae','fe_users',811,'usergroup','','','',0,1,0,'fe_groups',2,''),('13126a0ac6eea0a14c636713fb8bc772','fe_users',54,'usergroup','','','',0,0,0,'fe_groups',2,''),('131a0d72be6994660289f73ec391ebfa','fe_users',551,'usergroup','','','',0,0,0,'fe_groups',2,''),('13565b3a3a86f13742ebbbef650a08c8','fe_users',204,'usergroup','','','',0,0,0,'fe_groups',2,''),('1383afa612641d8a342fd6e4aa35947a','fe_users',224,'usergroup','','','',0,0,0,'fe_groups',2,''),('145fa338c8014c1fb08959f8d0552c56','fe_users',187,'usergroup','','','',0,0,0,'fe_groups',2,''),('14b095992ec5fc6190f1f4da4870b831','fe_users',728,'usergroup','','','',0,1,0,'fe_groups',2,''),('14d886cdfcddf7580f32a17419e760f1','fe_users',417,'usergroup','','','',0,0,0,'fe_groups',2,''),('14e7e6f3c06ebc4958758915eec4c4e6','fe_users',582,'usergroup','','','',0,0,0,'fe_groups',2,''),('153e0c93caa2d646b7aace1eb2d98143','fe_users',30,'usergroup','','','',0,0,0,'fe_groups',2,''),('1582433cc4a04741aa96920dcd83a699','fe_users',319,'usergroup','','','',0,0,0,'fe_groups',2,''),('15af27d4d4b06f24b06edf17ed792715','fe_users',650,'usergroup','','','',0,1,0,'fe_groups',2,''),('15c3ed91e589836e4d9e66e0272110c5','fe_users',831,'usergroup','','','',0,1,0,'fe_groups',2,''),('1639a4d241853d413a7028391aae1e1f','fe_users',139,'usergroup','','','',0,0,0,'fe_groups',2,''),('164daa3874c85a4af8335811abffd1b4','fe_users',241,'usergroup','','','',0,0,0,'fe_groups',2,''),('1676906326262adc3c13281dc3c2f4ee','fe_users',810,'usergroup','','','',0,1,0,'fe_groups',2,''),('16fba6c3f0065910b13454937055df19','fe_users',843,'usergroup','','','',0,0,0,'fe_groups',1,''),('173ee2308a46de97d20ed576a50b5093','fe_users',825,'usergroup','','','',0,1,0,'fe_groups',2,''),('176d8a6d04b72e030cc2a66601c17814','fe_users',195,'usergroup','','','',0,0,0,'fe_groups',2,''),('17e20f37c821462dbc75fe1e5f56c876','fe_users',268,'usergroup','','','',0,0,0,'fe_groups',2,''),('180eba4f8e30c30b1343be3ce49b8905','fe_users',640,'usergroup','','','',0,0,0,'fe_groups',2,''),('187e74de4a56ad7e64d1603edb2d0bc0','fe_users',607,'usergroup','','','',0,0,0,'fe_groups',2,''),('18a667e6c61e65d5b8982b256997a9ab','fe_users',462,'usergroup','','','',0,0,0,'fe_groups',2,''),('18bb41a8abd1f51fab683e10ca28fbf3','tt_content',4,'fe_group','','','',0,0,0,'fe_groups',-1,''),('18c8f7662406ceed5021656460b73978','fe_users',394,'usergroup','','','',0,0,0,'fe_groups',2,''),('19467ebcb1d9532b12fe9b2669416cb5','fe_users',788,'usergroup','','','',0,1,0,'fe_groups',2,''),('19495d9b8bdd3af73b32bbaec83f2fdd','fe_users',505,'usergroup','','','',0,0,0,'fe_groups',2,''),('19661f54e5618db3cf54d07fc1f79364','fe_users',302,'usergroup','','','',0,0,0,'fe_groups',2,''),('19761a9fef1c726b72542ea6181eabf7','fe_users',155,'usergroup','','','',0,0,0,'fe_groups',2,''),('19b027d4056000c2df3dc9681efcbfb5','fe_users',211,'usergroup','','','',0,0,0,'fe_groups',2,''),('19c0026ee8a62724600f71be145f9cdf','fe_users',843,'usergroup','','','',1,0,0,'fe_groups',2,''),('19f64855585c4b6d5d9b9aa692bea235','fe_users',531,'usergroup','','','',0,0,0,'fe_groups',2,''),('1a08d446414fe9e6d60a567b436e7358','fe_users',14,'usergroup','','','',0,0,0,'fe_groups',2,''),('1a300fe4b292768e810dcc88c892a8f8','fe_users',393,'usergroup','','','',0,0,0,'fe_groups',2,''),('1adcb3c3c18a8b3444a82c1b05dfba67','fe_users',541,'usergroup','','','',0,0,0,'fe_groups',2,''),('1aff258252a69e87bdd787b515a2ac16','fe_users',726,'usergroup','','','',0,1,0,'fe_groups',2,''),('1b6def589c7967ccb942564628acac66','fe_users',378,'usergroup','','','',0,0,0,'fe_groups',2,''),('1b7aa564367fe8a580ebe62bbe130646','fe_users',761,'usergroup','','','',0,1,0,'fe_groups',2,''),('1b828111033c77914105d172f38c7f40','fe_users',475,'usergroup','','','',0,0,0,'fe_groups',2,''),('1bb903275f35c2f6ea32d21e861a780d','fe_users',755,'usergroup','','','',0,1,0,'fe_groups',2,''),('1cd768bfe8ed945432044fb6b33e25dc','fe_users',496,'usergroup','','','',0,0,0,'fe_groups',2,''),('1d8241b92b450986883b729bbe9ce444','fe_users',532,'usergroup','','','',0,0,0,'fe_groups',2,''),('1dcffdd697cc8bbe7fcb8705079e6029','fe_users',449,'usergroup','','','',0,0,0,'fe_groups',2,''),('1dd1eab510342981fcfa7bc1e536ebdf','fe_users',457,'usergroup','','','',0,0,0,'fe_groups',2,''),('1df9fcdaeb7ef344229fbe2ce06a630a','fe_users',34,'usergroup','','','',0,0,0,'fe_groups',2,''),('1e1f80f677f22aa93acd01d30db8f24f','fe_users',415,'usergroup','','','',0,0,0,'fe_groups',2,''),('1ee811c0d77754cc7bbbf42efa70b26b','fe_users',39,'usergroup','','','',0,0,0,'fe_groups',2,''),('1faefd729a32139bee0b69cad5817aab','fe_users',803,'usergroup','','','',0,1,0,'fe_groups',2,''),('204971e7e50bf9481bb34177df91c310','fe_users',482,'usergroup','','','',0,0,0,'fe_groups',2,''),('20840e92906040c451eba5218a00f372','fe_users',842,'usergroup','','','',0,1,0,'fe_groups',2,''),('210b721d9adeab4d1b6544aa44e98ba8','fe_users',131,'usergroup','','','',0,0,0,'fe_groups',2,''),('21b8b146fd02802323950eb6fc3688fe','fe_users',285,'usergroup','','','',0,0,0,'fe_groups',2,''),('21c670f5d537dac2a1aaef8fc070eb0a','pages',11,'fe_group','','','',0,0,0,'fe_groups',2,''),('21ec76f6eb20d9d0e9a3944e25a0946e','fe_users',126,'usergroup','','','',0,0,0,'fe_groups',2,''),('21f84c3fdd920c2d4ee9be984b910596','fe_users',436,'usergroup','','','',0,0,0,'fe_groups',2,''),('220578bf573cf02dbe3cb83928bd0a0d','fe_users',599,'usergroup','','','',0,0,0,'fe_groups',2,''),('224bedb05d65dee1b91da9db0f12dc84','fe_users',412,'usergroup','','','',0,0,0,'fe_groups',2,''),('22a799d98be607d9f1fd41dccfb8c900','fe_users',681,'usergroup','','','',0,1,0,'fe_groups',2,''),('22e3d0e2cb63e42f2e2cde5778b3d7ae','fe_users',422,'usergroup','','','',0,0,0,'fe_groups',2,''),('230610d69b05d9a9f95b06b2053f4ddd','fe_users',680,'usergroup','','','',0,1,0,'fe_groups',2,''),('231601a762b21bd2ae099686300e672e','fe_users',603,'usergroup','','','',0,0,0,'fe_groups',2,''),('239b6bafeb0ee93bb178853adbbd51de','fe_users',699,'usergroup','','','',0,1,0,'fe_groups',2,''),('241a881c9181d0aa5dfa814072cf03cb','fe_users',808,'usergroup','','','',0,1,0,'fe_groups',2,''),('24e123eb148f510c16ae5cc16307548a','fe_users',23,'usergroup','','','',0,0,0,'fe_groups',2,''),('25157be81acbf336e6660eac2c296eea','fe_users',129,'usergroup','','','',0,0,0,'fe_groups',2,''),('2580cd894f0e58798016ace9bf7836a7','fe_users',193,'usergroup','','','',0,0,0,'fe_groups',2,''),('25bedeb5e8f51868f71e2bc7cdf8d80a','fe_users',325,'usergroup','','','',0,0,0,'fe_groups',2,''),('25e667cebfc7a58c3460a7d3e4bed225','fe_users',318,'usergroup','','','',0,0,0,'fe_groups',2,''),('25fcbb16060535670fbb8dd3531f585d','fe_users',106,'usergroup','','','',0,0,0,'fe_groups',2,''),('261dacca6854c5e00232e64e05f9734e','fe_users',452,'usergroup','','','',0,0,0,'fe_groups',2,''),('2626af303a4219819f4df9412f00256b','fe_users',476,'usergroup','','','',0,0,0,'fe_groups',2,''),('26620f8dac3de2bd2317f31c0575521c','fe_users',498,'usergroup','','','',0,0,0,'fe_groups',2,''),('26e00ea830ab842a9423fcf5606c4f80','fe_users',82,'usergroup','','','',0,0,0,'fe_groups',2,''),('26e1b8ad580266d93604336d30229ae4','fe_users',727,'usergroup','','','',0,1,0,'fe_groups',2,''),('26e331b4ceb32a74155cefd11a50718e','fe_users',127,'usergroup','','','',0,0,0,'fe_groups',2,''),('272d9935ac1f278ab32fe9090bcbbaed','fe_users',644,'usergroup','','','',0,1,0,'fe_groups',2,''),('274e4940270f34d60c6856413c847cd8','fe_users',389,'usergroup','','','',0,0,0,'fe_groups',2,''),('278f230254a48755c95dc9ad421902f2','fe_users',419,'usergroup','','','',0,0,0,'fe_groups',2,''),('27aa8d00386993fd30a34606dc0e6ea4','fe_users',97,'usergroup','','','',0,0,0,'fe_groups',2,''),('288cba286c5bcfc629a01842a8162a49','fe_users',821,'usergroup','','','',0,1,0,'fe_groups',2,''),('28dcd55eb02b7d22b73bd49b42b0767e','fe_users',618,'usergroup','','','',0,0,0,'fe_groups',2,''),('2980cbeb956f274483f97be10a1b5a11','tt_content',1,'pi_flexform','s_redirect/lDEF/settings.redirectPageLogin/vDEF/','','',0,0,0,'pages',1,''),('29b802a2da4befb946c628971151bf7b','pages',22,'l10n_parent','','','',0,0,0,'pages',9,''),('29eeb2dae39d179e20baaba0827db3ca','tt_content',15,'l18n_parent','','','',0,1,0,'tt_content',10,''),('2a05b6545cdd986f83e150d693cd472f','fe_users',375,'usergroup','','','',0,0,0,'fe_groups',2,''),('2a7371da29aedd8b5286fe00e20cb4c5','fe_users',326,'usergroup','','','',0,0,0,'fe_groups',2,''),('2b3cc49b19c5654240e10dac9bc8d594','fe_users',174,'usergroup','','','',0,0,0,'fe_groups',2,''),('2b6801d930a9ef5e0802d0f82f9b94b3','fe_users',612,'usergroup','','','',0,0,0,'fe_groups',2,''),('2bd2fe74b3307a0a30f88e62fb77d88f','fe_users',136,'usergroup','','','',0,0,0,'fe_groups',2,''),('2bea731bdaa1984c019c0c110dd8f555','fe_users',800,'usergroup','','','',0,1,0,'fe_groups',2,''),('2bfbb60fffa2e44a2fb250af634e4d9b','fe_users',63,'usergroup','','','',0,0,0,'fe_groups',2,''),('2c05cccfcbd3d710fbb1126805d8e4d7','fe_users',796,'usergroup','','','',0,1,0,'fe_groups',2,''),('2c2cc8d87ee1a4e4a0be225f8b9a0621','fe_users',844,'usergroup','','','',0,0,0,'fe_groups',1,''),('2c5b41da9e55677833b862449daad301','fe_users',826,'usergroup','','','',0,1,0,'fe_groups',2,''),('2c6ac73db57347af1b5482e889e8971f','fe_users',38,'usergroup','','','',0,0,0,'fe_groups',2,''),('2c71a6691589740b14c8aa6e970ed82a','pages',23,'l10n_parent','','','',0,0,0,'pages',6,''),('2cf28b62ffe4fc77c23b11714c26962a','fe_users',280,'usergroup','','','',0,0,0,'fe_groups',2,''),('2d0823ac34b9adb36bbfc5646da64173','fe_users',279,'usergroup','','','',0,0,0,'fe_groups',2,''),('2d229427f3802720cdba5097ff4535f6','fe_users',40,'usergroup','','','',0,0,0,'fe_groups',2,''),('2d53559e23726b6461797a002905e48a','pages',24,'l10n_parent','','','',0,0,0,'pages',7,''),('2db14790f636cc298972c96645a76cf0','fe_users',177,'usergroup','','','',0,0,0,'fe_groups',2,''),('2db2b97dbdd6cb9bc9f7b0ceb14c2107','fe_users',549,'usergroup','','','',1,0,0,'fe_groups',1,''),('2dd27af1aab5c1f099380a8f79285799','fe_users',522,'usergroup','','','',0,0,0,'fe_groups',2,''),('2de92e2498c78e96beac5cf1c817b155','fe_users',391,'usergroup','','','',0,0,0,'fe_groups',2,''),('2e0e5a248ed0a97b43847a9da32f9dcb','fe_users',198,'usergroup','','','',0,0,0,'fe_groups',2,''),('2e5c11c50e8ff5057627e5fe67040958','fe_users',217,'usergroup','','','',0,0,0,'fe_groups',2,''),('2eb8e4e441da5369cb9356270a376c42','fe_users',3,'usergroup','','','',0,0,0,'fe_groups',2,''),('2eb9bb0b95e2d2dd2526d507459c2afa','fe_users',317,'usergroup','','','',0,0,0,'fe_groups',2,''),('2ec490af3909859d6ede860605662396','fe_users',163,'usergroup','','','',0,0,0,'fe_groups',2,''),('2f2dd88d38094372532d69c90f62dfae','fe_users',349,'usergroup','','','',0,0,0,'fe_groups',2,''),('2f56fbc24b21848a04992bc02b0cc4e8','fe_users',418,'usergroup','','','',0,0,0,'fe_groups',2,''),('2f7cd98f8c6a0ae5bfe82e8f9a0f9cd7','fe_users',380,'usergroup','','','',0,0,0,'fe_groups',2,''),('2f7ff6401db79d6c174360aecf399258','fe_users',384,'usergroup','','','',0,0,0,'fe_groups',2,''),('2fa51c4463323872a138cfc56d3dca1f','fe_users',587,'usergroup','','','',0,0,0,'fe_groups',2,''),('2fab7cecf8c2b2b6c890d9c883fa8e5a','fe_users',824,'usergroup','','','',0,1,0,'fe_groups',2,''),('306a655b7421edf556a15820c83c6e63','fe_users',173,'usergroup','','','',0,0,0,'fe_groups',2,''),('30daef2b871e2271bae422427519cdc5','fe_users',113,'usergroup','','','',0,0,0,'fe_groups',2,''),('31068dd9ef8b5f26aee8dd6f5633d459','fe_users',701,'usergroup','','','',0,1,0,'fe_groups',2,''),('310efe54fbf3285aa1c59cc9b84073ef','fe_users',835,'usergroup','','','',0,1,0,'fe_groups',2,''),('317005ed15ba0aeb8e10b609012774b0','fe_users',159,'usergroup','','','',0,0,0,'fe_groups',2,''),('3179264f3be43e777c9789d24c6a1392','fe_users',767,'usergroup','','','',0,1,0,'fe_groups',2,''),('31ea8e742e847b77acbba675d35c159b','fe_users',78,'usergroup','','','',0,0,0,'fe_groups',2,''),('321317604230be5439ee59f9c28dbe42','fe_users',448,'usergroup','','','',0,0,0,'fe_groups',2,''),('327c99d3e5090a8b03cdf5eaa1299c36','fe_users',745,'usergroup','','','',0,1,0,'fe_groups',2,''),('337f45f81a90cd726417f3e6e8d0be99','fe_users',340,'usergroup','','','',0,0,0,'fe_groups',2,''),('340a315a491fce15664f3bc599139d1d','fe_users',72,'usergroup','','','',0,0,0,'fe_groups',2,''),('340c8b14f89cbef01ad2bd5622f07285','fe_users',789,'usergroup','','','',0,1,0,'fe_groups',2,''),('343d042f9f299f9109e0b715d9c02689','fe_users',565,'usergroup','','','',0,0,0,'fe_groups',2,''),('346beba2574b0a002248905c93f9ff22','fe_users',98,'usergroup','','','',0,0,0,'fe_groups',2,''),('3533b1e0ff4bf3c66c067389bd101f0b','fe_users',43,'usergroup','','','',0,0,0,'fe_groups',2,''),('35607be70f7f33d9eab104b0897976f1','fe_users',445,'usergroup','','','',0,0,0,'fe_groups',2,''),('36004f1ff5e944d18233dbdc2cd7447f','fe_users',535,'usergroup','','','',0,0,0,'fe_groups',2,''),('365ad79e604dc24f4a61c459120fc2af','fe_users',251,'usergroup','','','',0,0,0,'fe_groups',2,''),('365aeeb5ad0fdf610ef84385b1c8b95f','fe_users',21,'usergroup','','','',0,0,0,'fe_groups',2,''),('36d190d20d9d33637b7f5e12f32e2030','fe_users',312,'usergroup','','','',0,0,0,'fe_groups',2,''),('373031ff20e7dd8c4e8582356a824fe2','fe_users',518,'usergroup','','','',0,0,0,'fe_groups',2,''),('3778829bbf689a44d10fe49d746f8c68','fe_users',295,'usergroup','','','',0,0,0,'fe_groups',2,''),('3779a79f8a7c1322e47aa9ae75dd7486','fe_users',80,'usergroup','','','',0,0,0,'fe_groups',2,''),('3780e8b3f0abf287cd4f3cc690e2ed18','fe_users',697,'usergroup','','','',0,1,0,'fe_groups',2,''),('378c8fbb50fe5e9a34cc497824b9f486','pages',26,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('379b018846d247ad4c84c0834718f6ac','tt_content',1,'pi_flexform','sDEF/lDEF/settings.pages/vDEF/','','',0,0,0,'pages',8,''),('37b69676c3a864474948f7cd4289da79','fe_users',61,'usergroup','','','',0,0,0,'fe_groups',2,''),('37bfaaefa67d6d1665dce73aa1678d5c','fe_users',171,'usergroup','','','',0,0,0,'fe_groups',2,''),('37f6245d1bb16f1df1bdbb7b4506d15b','fe_users',814,'usergroup','','','',0,1,0,'fe_groups',2,''),('3871828969175a6e75b89ae354dccba3','fe_users',771,'usergroup','','','',0,1,0,'fe_groups',2,''),('38c891bd7236277ec0e4e6217f8cba23','fe_users',537,'usergroup','','','',0,0,0,'fe_groups',2,''),('38d55c6b2d117647534323754fc5b581','fe_users',579,'usergroup','','','',0,0,0,'fe_groups',2,''),('38eb0a78e5496101c09106a310ee1fb7','fe_users',296,'usergroup','','','',0,0,0,'fe_groups',2,''),('391e4c4ffd10bfc45c77beb5cb95965d','fe_users',120,'usergroup','','','',0,0,0,'fe_groups',2,''),('39c2a993ba1848f90ed54f67f98128de','fe_users',160,'usergroup','','','',0,0,0,'fe_groups',2,''),('3a93b72fc5b39c74aba7f7675f154d98','fe_users',51,'usergroup','','','',0,0,0,'fe_groups',2,''),('3ab5f1f4b6087967b26d7cd68407cbd0','fe_users',112,'usergroup','','','',0,0,0,'fe_groups',2,''),('3ac79c8a558dca8cd0e8dceddc39016a','fe_users',278,'usergroup','','','',0,0,0,'fe_groups',2,''),('3b07afbd6e037b3013528eb98ac371b9','fe_users',117,'usergroup','','','',0,0,0,'fe_groups',2,''),('3b3e09b1d8eadb40efa3facd7f4ff76c','fe_users',108,'usergroup','','','',0,0,0,'fe_groups',2,''),('3b63886e2bbfd800b7c762c0a01fca52','fe_users',219,'usergroup','','','',0,0,0,'fe_groups',2,''),('3b6bb1a5541586fd70a3ca5932779f6a','fe_users',736,'usergroup','','','',0,1,0,'fe_groups',2,''),('3bcd600c319e0f2027744fefcb294a74','fe_users',815,'usergroup','','','',0,1,0,'fe_groups',2,''),('3c483306fdeccff18958aa79841f8e15','fe_users',720,'usergroup','','','',0,1,0,'fe_groups',2,''),('3c4c0a189ab748b44e246ea477282df3','fe_users',215,'usergroup','','','',0,0,0,'fe_groups',2,''),('3c70c36d09454472e10168dd8cc84b7e','fe_users',176,'usergroup','','','',0,0,0,'fe_groups',2,''),('3ccb0071baf90cfce75ca67098201135','fe_users',641,'usergroup','','','',0,0,0,'fe_groups',2,''),('3ccf9a414976fa1784549bd1a6a67bd0','fe_users',586,'usergroup','','','',0,0,0,'fe_groups',2,''),('3d8f3572f56f5f5afce997ec96580f0b','fe_users',261,'usergroup','','','',0,0,0,'fe_groups',2,''),('3df09985529ad0da4098ca615aa89cdf','fe_users',210,'usergroup','','','',0,0,0,'fe_groups',2,''),('3df65a0055e5cf1bceb86126c03a7d0d','fe_users',427,'usergroup','','','',0,0,0,'fe_groups',2,''),('3e4cb18a84e70e9a086d59a14bb8dc6c','fe_users',228,'usergroup','','','',0,0,0,'fe_groups',2,''),('3e5ee16202194b7f4306f74df19ce6bf','fe_users',675,'usergroup','','','',0,1,0,'fe_groups',2,''),('3f044e30b0ba44835861456b672eea5e','fe_users',533,'usergroup','','','',0,0,0,'fe_groups',2,''),('3f27007ef89753178fdcb835203948a4','fe_users',804,'usergroup','','','',0,1,0,'fe_groups',2,''),('3f3d3a03f0590d957af4c326b0a5e225','fe_users',13,'usergroup','','','',0,0,0,'fe_groups',2,''),('3f48a0b26f79fca84af2989957936089','fe_users',545,'usergroup','','','',0,0,0,'fe_groups',2,''),('3f4a4bd3a754bb573ab406fd4dbae693','fe_users',557,'usergroup','','','',0,0,0,'fe_groups',2,''),('3ff3c677e60b9386d26dd52851b550a4','fe_users',263,'usergroup','','','',0,0,0,'fe_groups',2,''),('402d380aed1cf54e5f03668f69560f72','fe_users',465,'usergroup','','','',0,0,0,'fe_groups',1,''),('41583023619d64425d661f690dff75c5','fe_users',399,'usergroup','','','',0,0,0,'fe_groups',2,''),('4196f161efe84d63d9de9d7a69734376','fe_users',273,'usergroup','','','',0,0,0,'fe_groups',2,''),('41a901048d5cbae8377ebd9d57523746','fe_users',320,'usergroup','','','',0,0,0,'fe_groups',2,''),('41f554d1bf6d0d70261692b4de402791','fe_users',358,'usergroup','','','',0,0,0,'fe_groups',2,''),('421a13fc2f047634f4b65ab29e8ec3b8','fe_users',597,'usergroup','','','',0,0,0,'fe_groups',2,''),('421e31fb8bb33dbcece48cd3a7477aad','fe_users',208,'usergroup','','','',0,0,0,'fe_groups',2,''),('435481a6917ce713241f8c7da6c1e03b','fe_users',15,'usergroup','','','',0,0,0,'fe_groups',2,''),('437caca9381478a12ac2bf4250fc2c4a','fe_users',546,'usergroup','','','',0,0,0,'fe_groups',2,''),('43836e3eb62d690939ed0ee44900ab5c','fe_users',377,'usergroup','','','',0,0,0,'fe_groups',2,''),('4383d0e65d31282adea6c329c1304d9f','fe_users',401,'usergroup','','','',0,0,0,'fe_groups',2,''),('43a7c46f8f70ce8bbafbc22491958dee','fe_users',839,'usergroup','','','',0,1,0,'fe_groups',2,''),('44226aad0c31f8c8af03064779bfb510','fe_users',657,'usergroup','','','',0,1,0,'fe_groups',2,''),('44ac809705d474562f91931df1169546','fe_users',265,'usergroup','','','',0,0,0,'fe_groups',2,''),('459b405dcd6422ed0862301b16f99e24','fe_users',632,'usergroup','','','',0,0,0,'fe_groups',2,''),('45b84c1d30ee0de2e64cbd02701e29ba','fe_users',494,'usergroup','','','',0,0,0,'fe_groups',2,''),('4624eaf3b3b56c927b192ddec2da2b11','fe_users',206,'usergroup','','','',0,0,0,'fe_groups',2,''),('463e0e167145ea640ad9da8e70577564','fe_users',666,'usergroup','','','',0,1,0,'fe_groups',2,''),('465812a1f7a02a765bd674a64c873d54','fe_users',752,'usergroup','','','',0,1,0,'fe_groups',2,''),('467931ef08fd1c3979d3389ba93c328c','fe_users',361,'usergroup','','','',0,0,0,'fe_groups',2,''),('467da99c7db9eaacade3590f5f561f75','pages',20,'fe_group','','','',0,0,0,'fe_groups',2,''),('46bad64e35bd75317cdf83dc55e3440d','fe_users',119,'usergroup','','','',0,0,0,'fe_groups',2,''),('474ed28e16b2fbcc84c7ff187bd7195f','fe_users',47,'usergroup','','','',0,0,0,'fe_groups',2,''),('4757f849c68238f879357a11f3e75938','fe_users',656,'usergroup','','','',0,1,0,'fe_groups',2,''),('475e12961840d11d358097ca641e6af4','fe_users',85,'usergroup','','','',0,0,0,'fe_groups',2,''),('4780c267b89a9a84fc1cbeda9bf046de','fe_users',336,'usergroup','','','',0,0,0,'fe_groups',2,''),('478442e439896dc26bb70b296be5bb9f','fe_users',598,'usergroup','','','',0,0,0,'fe_groups',2,''),('4857a601f2a4f494833c13cea72d0cde','fe_users',152,'usergroup','','','',0,0,0,'fe_groups',2,''),('486e210ba29cff40a000662f2f86034a','sys_template',1,'constants','','url','7',-1,0,0,'_STRING',0,'https://ddev-kartenforum.ddev.site/'),('48e5577ca86633c7002edb20d6f6adac','fe_users',550,'usergroup','','','',0,0,0,'fe_groups',2,''),('490609d67a52d3c3b7094d0e6d04ac08','fe_users',705,'usergroup','','','',0,1,0,'fe_groups',2,''),('495eda506494ef94f165e8761d46516a','fe_users',105,'usergroup','','','',0,0,0,'fe_groups',2,''),('4961d3ee64fc51f99956885f560be1bc','fe_users',602,'usergroup','','','',0,0,0,'fe_groups',2,''),('497bf400cc0515f1c6b5eb67bb1e2b80','fe_users',802,'usergroup','','','',0,1,0,'fe_groups',2,''),('4c5070cdeb5e072f6324e8dad74c4c88','fe_users',62,'usergroup','','','',0,0,0,'fe_groups',2,''),('4c8cbf728d70cda2a7315e8d1da22400','fe_users',687,'usergroup','','','',0,1,0,'fe_groups',2,''),('4c9912f7ba6fc07f8c1767be2ead0a2d','fe_users',584,'usergroup','','','',0,0,0,'fe_groups',2,''),('4ca92903685930906fb54adf90bdb16d','fe_users',625,'usergroup','','','',0,0,0,'fe_groups',2,''),('4cbe5ccbb94a02bdf513afdae5f3371e','fe_users',135,'usergroup','','','',0,0,0,'fe_groups',2,''),('4cd8b2e4c7ad9b8039c2fe4205337ac8','fe_users',838,'usergroup','','','',0,1,0,'fe_groups',2,''),('4d01491c2b3d47249b5b03e1f86ce755','fe_users',438,'usergroup','','','',0,0,0,'fe_groups',2,''),('4d1759f2f007809203d41214768ab47c','fe_users',688,'usergroup','','','',0,1,0,'fe_groups',2,''),('4d19e24f74680773ff8dfd9f3e3f0fa7','fe_users',730,'usergroup','','','',0,1,0,'fe_groups',2,''),('4d3c1573afcf23b89df5c56ce3ec9ce1','fe_users',444,'usergroup','','','',0,0,0,'fe_groups',2,''),('4da489d938f970f8312e59475a5d427a','tt_content',14,'l18n_parent','','','',0,0,0,'tt_content',4,''),('4e63a5ddca683864fb0282e6583e3ef8','fe_users',247,'usergroup','','','',0,0,0,'fe_groups',2,''),('4e76e3a97eeee2dd280d897cc3ab6ebf','fe_users',662,'usergroup','','','',0,1,0,'fe_groups',2,''),('4e7b18dc45eeb9655d14c89bf5bf0362','tt_content',12,'l18n_parent','','','',0,0,0,'tt_content',2,''),('4edd0a8ffc0590151e49a6d7a604167c','fe_users',77,'usergroup','','','',0,0,0,'fe_groups',2,''),('4eef514607ffd74896ddd6b01fe1fec9','fe_users',132,'usergroup','','','',0,0,0,'fe_groups',2,''),('4f9e35360fdfbb51e30ca38c2544b9e9','fe_users',420,'usergroup','','','',0,0,0,'fe_groups',2,''),('500057eb9fb3d49332df222c7aba8797','fe_users',237,'usergroup','','','',0,0,0,'fe_groups',2,''),('50047f31a868447aa96d5fa179f4e3f6','fe_users',664,'usergroup','','','',0,1,0,'fe_groups',2,''),('50068183850b92b339a17b40e92dc593','fe_users',433,'usergroup','','','',0,0,0,'fe_groups',2,''),('50800041b9c7101d534048c812fb2e21','fe_users',327,'usergroup','','','',0,0,0,'fe_groups',2,''),('50ce46d2fd1641a40e57edb196fd33f4','fe_users',190,'usergroup','','','',0,0,0,'fe_groups',2,''),('51097e8422593e1719274d3479ec37d4','fe_users',413,'usergroup','','','',0,0,0,'fe_groups',2,''),('51c9f333788c6f0ea3000dcb7841ecc2','fe_users',793,'usergroup','','','',0,1,0,'fe_groups',2,''),('5358dc72fc37c3f26cac72d233844250','fe_users',624,'usergroup','','','',0,0,0,'fe_groups',2,''),('53b015b92a80e0ff598edec7aa1ed9bd','fe_users',68,'usergroup','','','',0,0,0,'fe_groups',2,''),('53fc90feabb6ce21aab381a3b88f2422','fe_users',722,'usergroup','','','',0,1,0,'fe_groups',2,''),('53fe4cbf0022a85ab49d3f0ec38132bf','fe_users',140,'usergroup','','','',0,0,0,'fe_groups',2,''),('54ae6971592370c291c00b84ea1e8818','fe_users',110,'usergroup','','','',0,0,0,'fe_groups',2,''),('5516f58a98f7c893077487335c7ee72a','fe_users',671,'usergroup','','','',0,1,0,'fe_groups',2,''),('55839f04f5e39ac7a484233ef93fa55d','fe_users',207,'usergroup','','','',0,0,0,'fe_groups',2,''),('5660628ab7c577e6cd429d0a763f95e1','fe_users',334,'usergroup','','','',0,0,0,'fe_groups',2,''),('56810091b4bad25105941335b51b9e16','fe_users',4,'usergroup','','','',0,0,0,'fe_groups',2,''),('56a59a87f0e89e4691e405cb00081c50','fe_users',130,'usergroup','','','',0,0,0,'fe_groups',2,''),('57181177844b326ed278b293676bd16a','pages',22,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('57bab41215c97eccb163a1c3a5ddf0f9','fe_users',437,'usergroup','','','',0,0,0,'fe_groups',2,''),('57bd4a26993549de7c81ae56c65f8d77','fe_users',398,'usergroup','','','',0,0,0,'fe_groups',2,''),('589fad3f9b060e0458aff018013c7fc4','fe_users',196,'usergroup','','','',0,0,0,'fe_groups',2,''),('58a3699eff7b17d9ba01d3d2b2065481','fe_users',291,'usergroup','','','',0,0,0,'fe_groups',2,''),('58e36959608d61b78ab490155b98ce25','fe_users',216,'usergroup','','','',0,0,0,'fe_groups',2,''),('58febf527591d7c7fd3e198b17a6a98d','fe_users',750,'usergroup','','','',0,1,0,'fe_groups',2,''),('5919e2cb67fd08fa094274a31d21d546','fe_users',490,'usergroup','','','',0,0,0,'fe_groups',2,''),('59482755ee9921188d3497d5cb4faa10','fe_users',272,'usergroup','','','',0,0,0,'fe_groups',2,''),('5a47e386f0158c048ebdf12177414083','fe_users',255,'usergroup','','','',0,0,0,'fe_groups',2,''),('5ac7dede1d3936726ddcf3e2ef69d1f5','fe_users',510,'usergroup','','','',0,0,0,'fe_groups',2,''),('5af600359d42ce46e664b8285016df14','fe_users',776,'usergroup','','','',0,1,0,'fe_groups',2,''),('5b0c27353498ca29f19499c0271f2a63','fe_users',383,'usergroup','','','',0,0,0,'fe_groups',2,''),('5b45d97f59b28f8f9a0690dd40985e6e','fe_users',188,'usergroup','','','',0,0,0,'fe_groups',2,''),('5b5092314796690323afac72ad1daa18','fe_users',684,'usergroup','','','',0,1,0,'fe_groups',2,''),('5ba5dcc4d42a2cad39bd4e0095e7d685','fe_users',606,'usergroup','','','',0,0,0,'fe_groups',2,''),('5bebb84638691b6d66ecd21e3f8b8e5c','pages',21,'l10n_parent','','','',0,0,0,'pages',1,''),('5c510e016ed6a099cba700f25d43cc21','fe_users',259,'usergroup','','','',0,0,0,'fe_groups',2,''),('5c8f5fd578cacd45ab599c0d5f399784','fe_users',661,'usergroup','','','',0,1,0,'fe_groups',2,''),('5c9b81b72ce75fa940da1d5e86d2aeb4','fe_groups',1,'subgroup','','','',0,0,0,'fe_groups',2,''),('5d76c885c4bf509c9c974475af975403','fe_users',151,'usergroup','','','',0,0,0,'fe_groups',2,''),('5db8c258eb6d91e72c98433c666d0793','fe_users',764,'usergroup','','','',0,1,0,'fe_groups',2,''),('5de9c59ad2495b0805ae0eaa07a5914d','fe_users',353,'usergroup','','','',0,0,0,'fe_groups',2,''),('5e1cee5295f38426d2bc484b0a38110e','fe_users',382,'usergroup','','','',0,0,0,'fe_groups',2,''),('5f2aadf2bae9ba2cfb631d15bd570192','fe_users',46,'usergroup','','','',0,0,0,'fe_groups',2,''),('601c68bc060255891f7544e3fe0296ca','fe_users',180,'usergroup','','','',0,0,0,'fe_groups',2,''),('6030ed58107df6e8d54ed427fa8db3f1','fe_users',790,'usergroup','','','',0,1,0,'fe_groups',2,''),('60c4215bb9a409a1f14a75d572c21015','fe_users',799,'usergroup','','','',0,1,0,'fe_groups',2,''),('61f6e2d4e49d8e147ff08a0ae0892c95','fe_users',609,'usergroup','','','',0,0,0,'fe_groups',2,''),('6277a9b748582853b518293b252cb58e','fe_users',747,'usergroup','','','',0,1,0,'fe_groups',2,''),('6288d5d55e1569414eb1480132d87611','fe_users',759,'usergroup','','','',0,1,0,'fe_groups',2,''),('62b933d263cd8e935544ef9eee555ec8','fe_users',300,'usergroup','','','',0,0,0,'fe_groups',2,''),('62e8c8a64dfd1515ce81c01429c07b7f','fe_users',629,'usergroup','','','',0,0,0,'fe_groups',2,''),('62f4685eec921ab3fa05f0b0c4b3ff6b','fe_users',96,'usergroup','','','',0,0,0,'fe_groups',2,''),('6353a1af28d1c4ca35dd625b443de2c4','fe_users',286,'usergroup','','','',0,0,0,'fe_groups',2,''),('63619113e0fb37105c8802388255f93d','fe_users',610,'usergroup','','','',0,0,0,'fe_groups',2,''),('636da39f829123c161c832f62785a04f','fe_users',441,'usergroup','','','',0,0,0,'fe_groups',2,''),('636fcdf9b13feec0b51d140bf5f3c52b','fe_users',352,'usergroup','','','',0,0,0,'fe_groups',2,''),('63f1671164a1633dee8a6595307297d2','fe_users',197,'usergroup','','','',0,0,0,'fe_groups',2,''),('640bcc5812ac5eb975c33c07278d954e','fe_users',385,'usergroup','','','',0,0,0,'fe_groups',2,''),('6417360190f8695c45e80249cb389d8a','fe_users',9,'usergroup','','','',0,0,0,'fe_groups',2,''),('642d1a8c1751cb61e729c2343b86cad3','fe_users',8,'usergroup','','','',0,0,0,'fe_groups',2,''),('64819ca6bc384c3769d24aeca6e675da','fe_users',836,'usergroup','','','',0,1,0,'fe_groups',2,''),('649e420ee1d1b3faced27151a9b8c8e8','fe_users',594,'usergroup','','','',0,0,0,'fe_groups',2,''),('64bb465667e2870778bb299f470cd535','pages',24,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('64dbddca34f37152f45fcbdf306d5aa1','fe_users',324,'usergroup','','','',0,0,0,'fe_groups',2,''),('656c4a4e43eecfcb3c8929278f859d69','fe_users',10,'usergroup','','','',0,0,0,'fe_groups',2,''),('65b824afab7e5c2539dc5f2e1261fa5a','fe_users',567,'usergroup','','','',0,0,0,'fe_groups',2,''),('65c88e77a63cd6f7c2887be8838fe2d3','fe_users',611,'usergroup','','','',0,0,0,'fe_groups',2,''),('66353b712d4d0479fbf154c4f6224d37','fe_users',682,'usergroup','','','',0,1,0,'fe_groups',2,''),('664c3b8134a326fff9dea621398d343f','fe_users',757,'usergroup','','','',0,1,0,'fe_groups',2,''),('664f64237a7775a9c5500dc9b766ad87','fe_users',521,'usergroup','','','',0,0,0,'fe_groups',2,''),('66dfafabff5765322a985eecc392aebd','fe_users',702,'usergroup','','','',0,1,0,'fe_groups',2,''),('673185c8fd43c2b7c85b1a80fb35f232','fe_users',165,'usergroup','','','',0,0,0,'fe_groups',2,''),('67676be0326784a7a55f8cb7eb1791a9','fe_users',256,'usergroup','','','',0,0,0,'fe_groups',2,''),('6779aaf8687b766db6d0c3631badc636','fe_users',751,'usergroup','','','',0,1,0,'fe_groups',2,''),('67a4a330aff1f8edcc0744a3036deae0','fe_users',731,'usergroup','','','',0,1,0,'fe_groups',2,''),('686e2d4fe757fd5300ca79ca89780fba','fe_users',833,'usergroup','','','',0,1,0,'fe_groups',2,''),('68c47c24b1842d1c1354679d3ba08743','fe_users',461,'usergroup','','','',0,0,0,'fe_groups',2,''),('69067a993086dddbb8e5f6ca2b6a7f19','fe_users',24,'usergroup','','','',0,0,0,'fe_groups',2,''),('69199cdefb95bdd7d43a7ffadf177f65','fe_users',50,'usergroup','','','',0,0,0,'fe_groups',2,''),('69292675c7d0f5bd9f7e0d3219568067','fe_users',435,'usergroup','','','',0,0,0,'fe_groups',2,''),('697657e9db787a0a0f95fc1eec7212f9','fe_users',343,'usergroup','','','',0,0,0,'fe_groups',2,''),('69884aeb7830fa95c2bad6c0a8910576','fe_users',617,'usergroup','','','',0,0,0,'fe_groups',2,''),('6989c1fa69fdee69bf9918c9ab777054','fe_users',426,'usergroup','','','',0,0,0,'fe_groups',2,''),('6b126387c555c3d9bd54178d17e85d90','fe_users',146,'usergroup','','','',0,0,0,'fe_groups',2,''),('6b3e00cbc596d83fd6a09872102f899b','fe_users',570,'usergroup','','','',0,0,0,'fe_groups',2,''),('6b3ff0c5180b57624dba386457037cb6','fe_users',451,'usergroup','','','',0,0,0,'fe_groups',2,''),('6bc911d69b5e174cb97d0c68ad01145d','fe_users',184,'usergroup','','','',0,0,0,'fe_groups',2,''),('6c03af328a9b63a1fd14d93a72335e51','fe_users',66,'usergroup','','','',0,0,0,'fe_groups',2,''),('6c03eaae584bd3d744d41056b8322474','fe_users',481,'usergroup','','','',0,0,0,'fe_groups',2,''),('6cab47e12892c41acc93597da3a7b833','fe_users',345,'usergroup','','','',0,0,0,'fe_groups',2,''),('6d6ca725aa0afe9bde26bd1da57b1a03','fe_users',600,'usergroup','','','',0,0,0,'fe_groups',2,''),('6e0680edb4e3c3597a37006c180093f0','fe_users',49,'usergroup','','','',0,0,0,'fe_groups',2,''),('6edad492f3694ad7e94b92dd3bcd0ea7','fe_users',703,'usergroup','','','',0,1,0,'fe_groups',2,''),('6f0780c61a72fc93c2b96d666d681bed','fe_users',73,'usergroup','','','',0,0,0,'fe_groups',2,''),('6f6207f785ca59c14f005c1fe554c791','fe_users',89,'usergroup','','','',0,0,0,'fe_groups',2,''),('6f6765c8c815c45325a75c6b220497c0','fe_users',55,'usergroup','','','',0,0,0,'fe_groups',2,''),('6fcb77fc569d1b2e03f6f98abac23470','fe_users',619,'usergroup','','','',0,0,0,'fe_groups',2,''),('70194c9cde20f8d372dd5cabff00d9f7','tt_content',2,'fe_group','','','',0,0,0,'fe_groups',-1,''),('70363484e63fd98b0b2a5b280265c331','fe_users',508,'usergroup','','','',0,0,0,'fe_groups',2,''),('705cfa70d83ad0fd33d1a74e3023c15f','fe_users',484,'usergroup','','','',0,0,0,'fe_groups',2,''),('70cb6ad4ade3a9a4c78f2b7e55b6579a','fe_users',411,'usergroup','','','',0,0,0,'fe_groups',2,''),('70f063624fbe33ec4392d574ec632d33','fe_users',321,'usergroup','','','',0,0,0,'fe_groups',2,''),('71141f08e4e6b78118b432ac50a0f5fc','fe_users',390,'usergroup','','','',0,0,0,'fe_groups',2,''),('716acefe0a11792010e3764ab4c51b30','fe_users',269,'usergroup','','','',0,0,0,'fe_groups',2,''),('7209b96fbe748219a7e14c11457563d2','fe_users',564,'usergroup','','','',0,0,0,'fe_groups',2,''),('723aa22bb1ef273effae5f3bec997c33','fe_users',554,'usergroup','','','',0,0,0,'fe_groups',2,''),('726e26cbcfb7a0cd38c3d98f8ee0723a','fe_users',292,'usergroup','','','',0,0,0,'fe_groups',2,''),('72b47e5fab61b0cc57dc23cab8d465fa','fe_users',819,'usergroup','','','',0,1,0,'fe_groups',2,''),('730db1f70195db0cb455caeddd5c0f08','fe_users',348,'usergroup','','','',0,0,0,'fe_groups',2,''),('742a887bbf25ebf6322702807f0c64a3','fe_users',281,'usergroup','','','',0,0,0,'fe_groups',2,''),('74a1894973fcc02cb1b67243bebf434d','fe_users',574,'usergroup','','','',0,0,0,'fe_groups',2,''),('74a19477933cb22720cac02f3f2f168b','pages',23,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('75292ca8542933defacda5364349069e','fe_users',665,'usergroup','','','',0,1,0,'fe_groups',2,''),('7553d25e13dd7fa098d0b983f9dcc700','fe_users',816,'usergroup','','','',0,1,0,'fe_groups',2,''),('7571355e72af7ba75e2a8286abe9de8d','fe_users',807,'usergroup','','','',0,1,0,'fe_groups',2,''),('75a98b65048da54e5cd767d3e674b1fb','fe_users',502,'usergroup','','','',0,0,0,'fe_groups',2,''),('75ac9eef40b3a5b50c8d39e085cf3b2a','fe_users',660,'usergroup','','','',0,1,0,'fe_groups',2,''),('75b070927ec1429544058be99b1c0de6','fe_users',443,'usergroup','','','',0,0,0,'fe_groups',2,''),('75cb5cdd8467fbde6dee19444c5653a5','fe_users',138,'usergroup','','','',0,0,0,'fe_groups',2,''),('75dccd9472445281fbfedf7880897706','fe_users',711,'usergroup','','','',0,1,0,'fe_groups',2,''),('762d2809771593bfc5ad661e4afdd11a','fe_users',252,'usergroup','','','',0,0,0,'fe_groups',2,''),('768cc99a5a4aab356546411f172eb773','fe_users',128,'usergroup','','','',0,0,0,'fe_groups',2,''),('76d7bee535b24373e0a2f1dbb17be2f1','fe_users',421,'usergroup','','','',0,0,0,'fe_groups',2,''),('772d36936982afa686f07539939a88ba','fe_users',400,'usergroup','','','',0,0,0,'fe_groups',2,''),('774e50943f1591aef8bf6ff53612fa17','fe_users',562,'usergroup','','','',0,0,0,'fe_groups',2,''),('784b8aa9f40e03b1f9c252a297caa625','fe_users',474,'usergroup','','','',0,0,0,'fe_groups',2,''),('784d0d8193170411250c383f17c980bc','fe_users',125,'usergroup','','','',0,0,0,'fe_groups',2,''),('78598a42e9db59cc40ea6630e4d30d04','fe_users',303,'usergroup','','','',0,0,0,'fe_groups',2,''),('78e7dc0d22b4dfbd682b356c5f6f193c','fe_users',249,'usergroup','','','',0,0,0,'fe_groups',2,''),('78fc340c8b5e7ac675451244b363dbc7','fe_users',231,'usergroup','','','',0,0,0,'fe_groups',2,''),('78fcf4e1a7762aefc48791d2f235c807','fe_users',820,'usergroup','','','',0,1,0,'fe_groups',2,''),('79412da049e2af4b7a4b299b98d4929c','fe_users',245,'usergroup','','','',0,0,0,'fe_groups',2,''),('796aca797090e973e07f6a3f8d8f6c22','fe_users',221,'usergroup','','','',0,0,0,'fe_groups',2,''),('797f604eade4dcefef458a1e20ff5833','fe_users',244,'usergroup','','','',0,0,0,'fe_groups',2,''),('79c1f15a3c6630b1fda3f2e394bb5966','fe_users',230,'usergroup','','','',0,0,0,'fe_groups',2,''),('79c7c7475e2b8aa80002d968d6d09380','fe_users',27,'usergroup','','','',0,0,0,'fe_groups',2,''),('79e7df50b0eb18a1a06b9b533bda21a9','fe_users',305,'usergroup','','','',0,0,0,'fe_groups',2,''),('79f54cc6258ecbc9fa3a3a1c7339c24b','fe_users',605,'usergroup','','','',0,0,0,'fe_groups',2,''),('7a53f0ac2dd189c777d6f615da201de1','fe_users',483,'usergroup','','','',0,0,0,'fe_groups',2,''),('7b4fc7047cf36e22659d5ec09e350547','fe_users',465,'usergroup','','','',1,0,0,'fe_groups',2,''),('7c2ac288e51b53398f5820170021d1bb','fe_users',359,'usergroup','','','',0,0,0,'fe_groups',2,''),('7cfb5c14c313f622900d5d400c41d8ad','tt_content',11,'l18n_parent','','','',0,1,0,'tt_content',5,''),('7da0baf556549dea67600c8b3322808e','fe_users',424,'usergroup','','','',0,0,0,'fe_groups',2,''),('7db1c533ea59a92ea87496f8130eb3af','fe_users',690,'usergroup','','','',0,1,0,'fe_groups',2,''),('7e2931dacc23b23cdb71bea1b6c08a00','fe_users',766,'usergroup','','','',0,1,0,'fe_groups',2,''),('7eba47fbc93b5bc78ab94d8d316e20a8','fe_users',715,'usergroup','','','',0,1,0,'fe_groups',2,''),('7f086c0a12580be3a4956e66ad3e0cc3','fe_users',729,'usergroup','','','',0,1,0,'fe_groups',2,''),('7f2b39c1adf1299bb726c89296b68e9d','fe_users',649,'usergroup','','','',0,1,0,'fe_groups',2,''),('7f406d659c6751f4369c07f3739cbaa6','fe_users',676,'usergroup','','','',0,1,0,'fe_groups',2,''),('7f519f7c39790b46c8945e6e49c0b67f','fe_users',271,'usergroup','','','',0,0,0,'fe_groups',2,''),('7f551888ded0bc23cddd8e7c6eb932b1','fe_users',683,'usergroup','','','',0,1,0,'fe_groups',2,''),('7f9350f44b3fb9fdd57962d796390ab5','fe_users',513,'usergroup','','','',0,0,0,'fe_groups',2,''),('7fa8576ac2b118b5137555742293410b','fe_users',539,'usergroup','','','',0,0,0,'fe_groups',2,''),('7ffb513f8d2b4cf0a4ad9713521bce2f','fe_users',646,'usergroup','','','',0,1,0,'fe_groups',2,''),('806aa9a782e2af869569d4b489f9e8fc','fe_users',338,'usergroup','','','',0,0,0,'fe_groups',2,''),('80beb8074de01e04219445dbdc97b413','fe_users',812,'usergroup','','','',0,1,0,'fe_groups',2,''),('80d09ac2c6c880d9868085de0ecb336d','fe_users',591,'usergroup','','','',0,0,0,'fe_groups',2,''),('80f8565193d8c7982b73f76fba19bffb','fe_users',289,'usergroup','','','',0,0,0,'fe_groups',2,''),('8183dccea3f404d2f4390af9666d02c5','fe_users',161,'usergroup','','','',0,0,0,'fe_groups',2,''),('82d6f2eff386353d95a2a7b17545c555','fe_users',258,'usergroup','','','',0,0,0,'fe_groups',2,''),('83cf5eaace84dd673b2dbadbaaffbbbe','fe_users',99,'usergroup','','','',0,0,0,'fe_groups',2,''),('83e103937b9f7b5d64854db83570591f','fe_users',434,'usergroup','','','',0,0,0,'fe_groups',2,''),('840b2855d27eefa519526e397dbd2d49','fe_users',653,'usergroup','','','',0,1,0,'fe_groups',2,''),('841b5b6af9f26c9b2542f42f306576ba','fe_users',366,'usergroup','','','',0,0,0,'fe_groups',2,''),('8459685e40efd254f4428302bc55621a','fe_users',191,'usergroup','','','',0,0,0,'fe_groups',2,''),('846e46966870f65f5852d63fafc0186b','fe_users',86,'usergroup','','','',0,0,0,'fe_groups',2,''),('848aab3ea0cead7e0f9fe8bee34e1f07','fe_users',91,'usergroup','','','',0,0,0,'fe_groups',2,''),('855fc2735c7ee09871ded7971731978a','fe_users',797,'usergroup','','','',0,1,0,'fe_groups',2,''),('8587c254d124291182ce6d8ddf48af1a','fe_users',813,'usergroup','','','',0,1,0,'fe_groups',2,''),('85a27f2fa80ed1565e5e2085230906dc','fe_users',601,'usergroup','','','',0,0,0,'fe_groups',2,''),('85a6c28e29ae47e5e4c7d54ebf1cf317','fe_users',227,'usergroup','','','',0,0,0,'fe_groups',2,''),('85e2171bd0cd948243629252b9042597','fe_users',739,'usergroup','','','',1,0,0,'fe_groups',1,''),('85f19e37bac4ca69c8c9b603505415b0','fe_users',266,'usergroup','','','',0,0,0,'fe_groups',2,''),('8719db0960e5a71ffaa49de3fbebf795','fe_users',685,'usergroup','','','',0,1,0,'fe_groups',2,''),('873894a989d93e9602d9b498b922cc0f','fe_users',246,'usergroup','','','',0,0,0,'fe_groups',2,''),('87c29b382f22787a0486d23de772948f','fe_users',284,'usergroup','','','',0,0,0,'fe_groups',2,''),('87f38f2b518abdb3daac7c9e1aee8315','fe_users',769,'usergroup','','','',0,1,0,'fe_groups',2,''),('880e1d5072d0f7f026bd1570b293a731','fe_users',115,'usergroup','','','',0,0,0,'fe_groups',2,''),('88b9a900b33f81cc30186f24623fcbc9','fe_users',670,'usergroup','','','',0,1,0,'fe_groups',2,''),('891b41321dd4e527b91f8d273944feaa','fe_users',637,'usergroup','','','',0,0,0,'fe_groups',2,''),('8aa5ca100ebbedf58e806847e057d839','fe_users',509,'usergroup','','','',0,0,0,'fe_groups',2,''),('8ab16aa0a97ecc1f8f6a64444284bc42','fe_users',707,'usergroup','','','',0,1,0,'fe_groups',2,''),('8af54c1df9a0cbfaa846f000a60bf4e8','fe_users',192,'usergroup','','','',0,0,0,'fe_groups',2,''),('8b2ffcfee67b47c635824caf55360504','fe_users',772,'usergroup','','','',0,1,0,'fe_groups',2,''),('8b325e78d4369e680922f22bebc1117e','fe_users',65,'usergroup','','','',0,0,0,'fe_groups',2,''),('8b3599b31aa6667930afa42b8eacd1b6','fe_users',718,'usergroup','','','',0,1,0,'fe_groups',2,''),('8b5b372e07fd46546c982e1015641ef0','fe_users',220,'usergroup','','','',0,0,0,'fe_groups',2,''),('8b5b688f32e4e8b1e71093c3b67706a7','fe_users',834,'usergroup','','','',0,1,0,'fe_groups',2,''),('8bc5f3bfd279a7f02fbd2317d11c92a9','fe_users',692,'usergroup','','','',0,1,0,'fe_groups',2,''),('8bf3d02a043cff5785f8fc21b8b1de45','tt_content',9,'l18n_parent','','','',0,1,0,'tt_content',7,''),('8c21459bbbe3b15efbb6f348e3d34735','fe_users',738,'usergroup','','','',0,1,0,'fe_groups',2,''),('8c2dc6463f2de2e188716c4a9ddb6823','fe_users',354,'usergroup','','','',0,0,0,'fe_groups',2,''),('8c5046ecb8f7006ddf952bb1318ecda8','fe_users',262,'usergroup','','','',0,0,0,'fe_groups',2,''),('8c6417bc46bc86796de5731f7661364e','fe_users',199,'usergroup','','','',0,0,0,'fe_groups',2,''),('8c6799d27279aceee1971417a4502465','fe_users',339,'usergroup','','','',0,0,0,'fe_groups',2,''),('8d1f21effb5113fa5c1f394da50dba8c','fe_users',213,'usergroup','','','',0,0,0,'fe_groups',2,''),('8db2f417cfe7303cdc01eca1a2507d08','sys_template',1,'constants','','url','2',-1,0,0,'_STRING',0,'http://sdvvk20geo.slub-dresden.de/georeference'),('8db68ecbb57ed6976e6e16336a7d81bf','pages',28,'fe_group','','','',0,0,0,'fe_groups',1,''),('8e77dbbfacbc4b65fae27e42ebc2cf35','tt_content',17,'bodytext','','email','2',-1,0,0,'_STRING',0,'Generaldirektion@slub-dresden.de'),('8efdb572b4301575c8ff70bbb9659082','fe_users',783,'usergroup','','','',0,1,0,'fe_groups',2,''),('8f3b6b9fadb4c97caba1a0f3e9d83b80','fe_users',469,'usergroup','','','',0,0,0,'fe_groups',2,''),('8fd8673b27056e0729aa29deccb0263b','fe_users',12,'usergroup','','','',0,0,0,'fe_groups',2,''),('901bf316afeda09596ce44fd61633b59','fe_users',832,'usergroup','','','',0,1,0,'fe_groups',2,''),('90360d477d51f135968904dbc6c1ce27','fe_users',805,'usergroup','','','',0,1,0,'fe_groups',2,''),('908849f6168c58bdc3f6f3baffdaaba5','fe_users',712,'usergroup','','','',0,1,0,'fe_groups',2,''),('908c61f023642f519cfba742467f74b5','sys_template',1,'constants','','url','12',-1,0,0,'_STRING',0,'https://kartenforum.slub-dresden.de/spatialdocuments'),('90dfe3b5f95fee9300268db883d474a9','fe_users',786,'usergroup','','','',0,1,0,'fe_groups',2,''),('910b1956e9120d52554f8f0e2c024aed','fe_users',17,'usergroup','','','',0,0,0,'fe_groups',2,''),('91140aa7e0c0bdcb8ad73934254cf585','fe_users',423,'usergroup','','','',0,0,0,'fe_groups',2,''),('917de6cf2c6959b4b896d96e0ef2474c','tt_content',12,'fe_group','','','',0,0,0,'fe_groups',-1,''),('9191cd8e9a0ff2808d53447909c43f1d','fe_users',563,'usergroup','','','',0,0,0,'fe_groups',2,''),('91a9ec7d11afee03c4b7a7fff99db589','fe_users',186,'usergroup','','','',0,0,0,'fe_groups',2,''),('91e7b69b3a8b227bd18ad6d3b2762686','fe_users',270,'usergroup','','','',0,0,0,'fe_groups',2,''),('924e9e51688d8fd09a304876abe31cbc','fe_users',395,'usergroup','','','',0,0,0,'fe_groups',2,''),('92bd859ada8a2d9471f86a564ec2690d','fe_users',26,'usergroup','','','',0,0,0,'fe_groups',2,''),('92e06d5b20a51364e35f45bbbfa646ed','fe_users',386,'usergroup','','','',0,0,0,'fe_groups',2,''),('932b9bb81d81fb1bee87e0ecb65c3034','fe_users',691,'usergroup','','','',0,1,0,'fe_groups',2,''),('941eec945899409df8853ca41bb10a4b','fe_users',822,'usergroup','','','',0,1,0,'fe_groups',2,''),('94965b7d9a503a0a17b3865638b4407a','fe_users',341,'usergroup','','','',0,0,0,'fe_groups',2,''),('94fcfc3e787d0e7f5d74401afd41b64f','fe_users',20,'usergroup','','','',0,0,0,'fe_groups',2,''),('9561bbcb20f02777d0adc2dde27f47c6','fe_users',233,'usergroup','','','',0,0,0,'fe_groups',2,''),('95a1b7da6d212ad6d7be56972e13bec0','fe_users',360,'usergroup','','','',0,0,0,'fe_groups',2,''),('95c0efadf9386e0d4b76ea8da479fa11','fe_users',593,'usergroup','','','',0,0,0,'fe_groups',2,''),('962e2e569a4624cb64c0b4c80c457fa2','fe_users',580,'usergroup','','','',0,0,0,'fe_groups',2,''),('96b0a612c58868dd9cb6a947b3d815e0','fe_users',714,'usergroup','','','',0,1,0,'fe_groups',2,''),('975186677a86ee9f4e62676523e207a9','fe_users',430,'usergroup','','','',0,0,0,'fe_groups',2,''),('976d5fbe0cf954e4a15db970858428a6','fe_users',528,'usergroup','','','',0,0,0,'fe_groups',2,''),('9775bba219cb3e0426529370c028e281','fe_users',200,'usergroup','','','',0,0,0,'fe_groups',2,''),('98107853479e3208b624a23d726506b6','fe_users',740,'usergroup','','','',0,1,0,'fe_groups',2,''),('9818e7225426b8f83fb7a807813069ca','fe_users',364,'usergroup','','','',0,0,0,'fe_groups',2,''),('983becb051a2d60fb0fbc36af6b09f5e','fe_users',308,'usergroup','','','',0,0,0,'fe_groups',2,''),('98f6cdeab61850cfb44333ca8998b5e1','fe_users',742,'usergroup','','','',0,1,0,'fe_groups',2,''),('990bc8804a320c2ab9437187104fc881','fe_users',503,'usergroup','','','',0,0,0,'fe_groups',2,''),('99d71aabbfa3aac7d8596e15d68c8537','fe_users',402,'usergroup','','','',0,0,0,'fe_groups',2,''),('99fd5dd3a77128c61833f90d811d1e9b','fe_users',708,'usergroup','','','',0,1,0,'fe_groups',2,''),('9a19bcafa4f04f1db0c8c120ec3fdf7f','fe_users',495,'usergroup','','','',0,0,0,'fe_groups',2,''),('9a5db92db29401ab0ed0647bb62d9324','fe_users',792,'usergroup','','','',0,1,0,'fe_groups',2,''),('9a6497cfdb0e64d99c7a5b4465ea6e3f','fe_users',102,'usergroup','','','',0,0,0,'fe_groups',2,''),('9af7654faa3dac64642ec1f3a9a5ee09','tt_content',30,'pi_flexform','sDEF/lDEF/settings.loginPage/vDEF/','','',0,0,0,'pages',6,''),('9b110d3235a3691efbbacb5f745925d1','fe_users',754,'usergroup','','','',0,1,0,'fe_groups',2,''),('9c779da97a53a87efc2b6b97295a1055','fe_users',719,'usergroup','','','',0,1,0,'fe_groups',2,''),('9d37beedf6f7defc3fcf16d13fb867fb','fe_users',6,'usergroup','','','',0,0,0,'fe_groups',2,''),('9d82a4932543cfb7b5732d051fb34c05','fe_users',60,'usergroup','','','',0,0,0,'fe_groups',2,''),('9d971ee39f95b97cfe2e3603f5d337c0','fe_users',585,'usergroup','','','',0,0,0,'fe_groups',2,''),('9daacd189f76fb36bfd3ba326afdbb0b','fe_users',185,'usergroup','','','',0,0,0,'fe_groups',2,''),('9dd912515e91e9afd68223c61cb85260','fe_users',654,'usergroup','','','',0,1,0,'fe_groups',2,''),('9e102a5c37c8000b2d15b88c9a909a86','fe_users',218,'usergroup','','','',0,0,0,'fe_groups',2,''),('9e21428ead7a7e6bdf3c039ab7d62c2d','fe_users',548,'usergroup','','','',0,0,0,'fe_groups',2,''),('9e2c77cc90b6448b8df3eebde7bd01aa','fe_users',293,'usergroup','','','',0,0,0,'fe_groups',2,''),('9e97751928750aae2036499b7ca2ea7b','fe_users',523,'usergroup','','','',0,0,0,'fe_groups',2,''),('9e9b916dfd739c6916bb36bbe3e855d7','fe_users',571,'usergroup','','','',0,0,0,'fe_groups',2,''),('9ebeec5e448aa8fa38df9bb90211dcb7','fe_users',425,'usergroup','','','',0,0,0,'fe_groups',2,''),('9ee45e38da5c7945b140f9e5f91f6a54','fe_users',59,'usergroup','','','',0,0,0,'fe_groups',2,''),('9ee77e898d7eabd2bf47c863631f864a','fe_users',64,'usergroup','','','',0,0,0,'fe_groups',2,''),('9f4ae106a3503d765efd454adcaf7842','fe_users',464,'usergroup','','','',0,0,0,'fe_groups',2,''),('9f540db103bac5423676fce668be1afa','fe_users',577,'usergroup','','','',0,0,0,'fe_groups',2,''),('9f657f14549bf8cbfa9bdfba6d920735','fe_users',472,'usergroup','','','',0,0,0,'fe_groups',2,''),('9f688f141a8bbdaaf8637a1d5d4db10d','fe_users',827,'usergroup','','','',0,1,0,'fe_groups',2,''),('9f959e8a2c7a0ea4ba70afa3fd0f4e28','fe_users',202,'usergroup','','','',0,0,0,'fe_groups',2,''),('9faaa9f6cd57374ba4732ff45e58be51','fe_users',536,'usergroup','','','',0,0,0,'fe_groups',2,''),('a07d638d8f0fc829de9e6ed4c63dd1d2','fe_users',552,'usergroup','','','',0,0,0,'fe_groups',2,''),('a11f99743260027a4be7a10925331ddd','fe_users',614,'usergroup','','','',0,0,0,'fe_groups',2,''),('a1950d0f74228293d25b05f5c929c8ae','pages',26,'l10n_parent','','','',0,0,0,'pages',3,''),('a1f82f5e0600f57219a37c2deaf7403e','fe_users',397,'usergroup','','','',0,0,0,'fe_groups',2,''),('a2024d34ba29692366c3aec5a49d345f','fe_users',357,'usergroup','','','',0,0,0,'fe_groups',2,''),('a247434efb7c1525e533b379ed942e6c','pages',21,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('a2707af977540a6782031b449ebb4a2c','fe_users',721,'usergroup','','','',0,1,0,'fe_groups',2,''),('a282d8d7d1e4459b4df085bbffec0db1','fe_users',32,'usergroup','','','',0,0,0,'fe_groups',2,''),('a2b554fb6b213f854481d1281671cb2b','fe_users',818,'usergroup','','','',0,1,0,'fe_groups',2,''),('a2bc6ab09cd23b1490f42cb2269e814f','fe_users',297,'usergroup','','','',0,0,0,'fe_groups',2,''),('a2da595c2ecaa40870a6bc1a4f1fe6b9','fe_users',145,'usergroup','','','',0,0,0,'fe_groups',2,''),('a2f787918b0a49ee6cc123ea883e5c98','fe_users',450,'usergroup','','','',0,0,0,'fe_groups',2,''),('a2fa29a430bb7c768fdba4ec93df33d1','fe_users',566,'usergroup','','','',0,0,0,'fe_groups',2,''),('a3197766dd4219354b77258a33d0c17b','fe_users',351,'usergroup','','','',0,0,0,'fe_groups',2,''),('a3d66b2400f35e31388ee540466c6e6d','fe_users',33,'usergroup','','','',0,0,0,'fe_groups',2,''),('a3d76a46744f983c7a698eaa23ed9738','fe_users',529,'usergroup','','','',0,0,0,'fe_groups',2,''),('a3e9da4e59209a6d5b62958e37625c98','fe_users',168,'usergroup','','','',0,0,0,'fe_groups',2,''),('a409388540e26246e3e9c9a1215418e9','fe_users',527,'usergroup','','','',0,0,0,'fe_groups',2,''),('a49ae5452475b9f94c519ce8fa9ea8a4','fe_users',232,'usergroup','','','',0,0,0,'fe_groups',2,''),('a4e1eb0f137c23d6e5485f5c5aa880b1','fe_users',372,'usergroup','','','',0,0,0,'fe_groups',2,''),('a4f02a7a62b85511c8ab38690a08681e','fe_users',706,'usergroup','','','',0,1,0,'fe_groups',2,''),('a525fd3ac9d61f6e3f68219b27a0aa33','fe_users',225,'usergroup','','','',0,0,0,'fe_groups',2,''),('a59da4cf9f5b1ab308a7e0eabfef2c7a','fe_users',581,'usergroup','','','',0,0,0,'fe_groups',2,''),('a5b4749bb363b32052931af28fc7bdc1','fe_users',71,'usergroup','','','',0,0,0,'fe_groups',2,''),('a5d28ca778f89f8c6c85816c5c75155a','fe_users',107,'usergroup','','','',0,0,0,'fe_groups',2,''),('a6162358a5ea05b30f8364a32a62e02f','fe_users',362,'usergroup','','','',0,0,0,'fe_groups',2,''),('a62f6f620c6e656ecdfa38c2ac29aa58','fe_users',735,'usergroup','','','',0,1,0,'fe_groups',2,''),('a6437cedf81a9cce73242764db85adc1','fe_users',137,'usergroup','','','',0,0,0,'fe_groups',2,''),('a64c9bca8d09a808b59193b5d3b9e63c','fe_users',543,'usergroup','','','',0,0,0,'fe_groups',2,''),('a68194b887d4da5a7ae87616fd6ed21c','fe_users',408,'usergroup','','','',0,0,0,'fe_groups',2,''),('a746b9665b8566753e2e9bf77d7b4690','fe_users',18,'usergroup','','','',0,0,0,'fe_groups',2,''),('a765c2a3aa74c66d0146499acea36e0f','fe_users',774,'usergroup','','','',0,1,0,'fe_groups',2,''),('a7ed7678572d987a956d2772eb5c584b','fe_users',16,'usergroup','','','',0,0,0,'fe_groups',2,''),('a7ef803c3882a1b3dcd649bde36796a8','fe_users',347,'usergroup','','','',0,0,0,'fe_groups',2,''),('a835803d0ecb9b2a0c9f72702bb117ea','fe_users',311,'usergroup','','','',0,0,0,'fe_groups',2,''),('a86ffefc52d7ca6ba16bfb0a1369a06d','fe_users',710,'usergroup','','','',0,1,0,'fe_groups',2,''),('a8a66784464ceb8d42a2c687e25c9da1','fe_users',90,'usergroup','','','',0,0,0,'fe_groups',2,''),('a95343f70dcc9796204849c7d72c8258','fe_users',116,'usergroup','','','',0,0,0,'fe_groups',2,''),('a9773c65e13dd9b37295384c415c3d21','fe_users',667,'usergroup','','','',0,1,0,'fe_groups',2,''),('a9842c089e76e954c2730977b107f765','fe_users',672,'usergroup','','','',0,1,0,'fe_groups',2,''),('a98b4944274bdb54281ed380696f152f','fe_users',250,'usergroup','','','',0,0,0,'fe_groups',2,''),('aa6516eb2355bf6ab550b6bc8a9c9d81','fe_users',123,'usergroup','','','',0,0,0,'fe_groups',2,''),('aadd59b9175d8f01776543b9756a7b4a','fe_users',492,'usergroup','','','',0,0,0,'fe_groups',2,''),('aadf6e59e03e64830e9062a32d703b72','fe_users',592,'usergroup','','','',0,0,0,'fe_groups',2,''),('ab5fe9a46a54ee438a612cfef9087946','fe_users',235,'usergroup','','','',0,0,0,'fe_groups',2,''),('ab709e023f894652385dfad1c40cf050','fe_users',333,'usergroup','','','',0,0,0,'fe_groups',2,''),('abbcb4cdcf6eb76006908195fede4cc0','fe_users',643,'usergroup','','','',0,1,0,'fe_groups',2,''),('ac10b07ba1db53046328c1ae814e1cc8','fe_users',189,'usergroup','','','',0,0,0,'fe_groups',2,''),('ac47a0c1237121a60854a613dfbaafa3','fe_users',406,'usergroup','','','',0,0,0,'fe_groups',2,''),('ac52efa105a29540d9a7e649e696293a','fe_users',194,'usergroup','','','',0,0,0,'fe_groups',2,''),('acc6d66c2a2f76a9e6b6afa76a63862c','fe_users',387,'usergroup','','','',0,0,0,'fe_groups',2,''),('acfad7497f185acac46f6a71f883c97e','fe_users',243,'usergroup','','','',0,0,0,'fe_groups',2,''),('ad3c12c32f00b2c1799fb8f59b122e56','fe_users',674,'usergroup','','','',0,1,0,'fe_groups',2,''),('ad6065eca8a9dfdd55a3355bf9fb3f22','fe_users',773,'usergroup','','','',0,1,0,'fe_groups',2,''),('ad9b1970a6310d0ef1fdc991173c1bfa','fe_users',795,'usergroup','','','',0,1,0,'fe_groups',2,''),('ad9e63cf56018cc1b0b29ce55f4d6e18','fe_users',322,'usergroup','','','',0,0,0,'fe_groups',2,''),('adb3f628084837f6d6cce7d6cf58039c','fe_users',616,'usergroup','','','',0,0,0,'fe_groups',2,''),('adb51f0aaa05489dccf9bc330431e02e','fe_users',553,'usergroup','','','',0,0,0,'fe_groups',2,''),('ae59a24016b518156d01073ec0e83836','fe_users',118,'usergroup','','','',0,0,0,'fe_groups',2,''),('aea3781b76ca53184935f7b26156e9f9','fe_users',355,'usergroup','','','',0,0,0,'fe_groups',2,''),('aea47c03ab7a8844615f18affd7076c7','fe_users',264,'usergroup','','','',0,0,0,'fe_groups',2,''),('af0920b9a867562c1bc8de48ea504515','fe_users',596,'usergroup','','','',0,0,0,'fe_groups',2,''),('af33b2aa677c298c7f0773e3afbed7c9','fe_users',147,'usergroup','','','',0,0,0,'fe_groups',2,''),('af3ad5704f0db020f4629715740c1992','fe_users',743,'usergroup','','','',0,1,0,'fe_groups',2,''),('af7cb9b1f86e515f74342c7fa658a285','fe_users',760,'usergroup','','','',0,1,0,'fe_groups',2,''),('afa298b33fa9711434c414a696e4355f','fe_users',37,'usergroup','','','',0,0,0,'fe_groups',2,''),('aff9c226aa8ab3503dcbf1b73015a8ff','fe_users',460,'usergroup','','','',0,0,0,'fe_groups',2,''),('b070454f3261272c30af140514d91ab1','fe_users',154,'usergroup','','','',0,0,0,'fe_groups',2,''),('b08b7b30cdd1f87d56f7045d21a77a91','fe_users',223,'usergroup','','','',0,0,0,'fe_groups',2,''),('b12dad5fbd9589df6e5e9b3109c16e2c','fe_users',428,'usergroup','','','',0,0,0,'fe_groups',2,''),('b1315f6a325027205050c81764294b72','sys_file',1,'storage','','','',0,0,0,'sys_file_storage',1,''),('b132e9b2fb6e2ee5e4f9b94132afc562','fe_users',817,'usergroup','','','',0,1,0,'fe_groups',2,''),('b15cc071c2a9b3f794db1e3207a2f8ef','fe_users',473,'usergroup','','','',0,0,0,'fe_groups',2,''),('b15ce9fba62a650112b00897bcadb7d7','fe_users',254,'usergroup','','','',0,0,0,'fe_groups',2,''),('b1b8a7fec1e145ca7b344cb6177732cc','fe_users',622,'usergroup','','','',0,0,0,'fe_groups',2,''),('b24884c0bdf8b7b5b7428bbaec06ac6a','fe_users',156,'usergroup','','','',0,0,0,'fe_groups',2,''),('b26828725b5f48179226ab1e13d71c8c','fe_users',689,'usergroup','','','',0,1,0,'fe_groups',2,''),('b2f17c841544eda5af402a8beb4de228','fe_users',669,'usergroup','','','',0,1,0,'fe_groups',2,''),('b2f18ae0bd76ade5bb2e8b355202af39','fe_users',306,'usergroup','','','',0,0,0,'fe_groups',2,''),('b3f3c9e538748f7fcfe74b488f790f54','fe_users',480,'usergroup','','','',0,0,0,'fe_groups',2,''),('b448b11318286959556490b9c221e27f','fe_users',651,'usergroup','','','',0,1,0,'fe_groups',2,''),('b465f843dc4ebb63248b7f44004cb4f6','fe_users',294,'usergroup','','','',0,0,0,'fe_groups',2,''),('b469fa062e63bbde5fc42d82d0bde6b6','fe_users',724,'usergroup','','','',0,1,0,'fe_groups',2,''),('b4a9f6501eae7dc683d909f967ea1713','fe_users',56,'usergroup','','','',0,0,0,'fe_groups',2,''),('b4d3a3034d1d78a6fc88b6f335396f39','fe_users',499,'usergroup','','','',0,0,0,'fe_groups',2,''),('b50ee6bf1cedd2b54b55dde96e3c7e2e','fe_users',648,'usergroup','','','',0,1,0,'fe_groups',2,''),('b550ef4d3d0b79f5e15fd411f5162512','fe_users',511,'usergroup','','','',0,0,0,'fe_groups',2,''),('b58b1fd24c3246e6cb041f214ea4bfbe','fe_users',315,'usergroup','','','',0,0,0,'fe_groups',2,''),('b58c4233e1af15356701726a707d63bd','fe_users',181,'usergroup','','','',0,0,0,'fe_groups',2,''),('b620929b1c9380f0cb58b2cfc9cc459f','fe_users',36,'usergroup','','','',0,0,0,'fe_groups',2,''),('b6367a62984cf369358d821bcabba096','tt_content',14,'fe_group','','','',0,0,0,'fe_groups',-1,''),('b653c73a8b176f9864832c6eb19452e5','fe_users',429,'usergroup','','','',0,0,0,'fe_groups',2,''),('b672261abc5bfecfeecbe947502601c1','fe_users',209,'usergroup','','','',0,0,0,'fe_groups',2,''),('b6fd00238f50a5c8eade2e70265c2bbd','fe_users',620,'usergroup','','','',0,0,0,'fe_groups',2,''),('b709692abc39769860b8bdd45005e166','fe_users',183,'usergroup','','','',0,0,0,'fe_groups',2,''),('b73505a45a7f7261412d83d8cb74d302','fe_users',101,'usergroup','','','',0,0,0,'fe_groups',2,''),('b7590197a2c8159edd5a4d37f01f7d53','fe_users',158,'usergroup','','','',0,0,0,'fe_groups',2,''),('b7751585a03bd390e718dd622f1f7554','fe_users',547,'usergroup','','','',0,0,0,'fe_groups',2,''),('b80eb2c58f93a75fa24dedf888dea5dc','fe_users',595,'usergroup','','','',0,0,0,'fe_groups',2,''),('b87ecf8800c85b59aa024d7f3cc9356a','fe_users',634,'usergroup','','','',0,0,0,'fe_groups',2,''),('b8a1ac0338942b36b30d7e60e5e68cb7','fe_users',29,'usergroup','','','',0,0,0,'fe_groups',2,''),('b8d6fbdb3dac41bdd2d977188f728bbf','fe_users',404,'usergroup','','','',0,0,0,'fe_groups',2,''),('b8db343039d0b3f6d64eec66a7b9f237','fe_users',639,'usergroup','','','',0,0,0,'fe_groups',2,''),('b8e2489150bc5d3a356687f95c9d7dea','fe_users',829,'usergroup','','','',0,1,0,'fe_groups',2,''),('b9765743417b90ba1b980ce3a6c46513','fe_users',274,'usergroup','','','',0,0,0,'fe_groups',2,''),('b9adaa2fde39a8d43df7ee2758e379e8','fe_users',621,'usergroup','','','',0,0,0,'fe_groups',2,''),('bab7c9cabfc61a43f6d89a06d2039ab5','fe_users',487,'usergroup','','','',0,0,0,'fe_groups',2,''),('bab8c739cb8c642b44cea73cad1f937d','fe_users',517,'usergroup','','','',0,0,0,'fe_groups',2,''),('bac92e4516496604c56b8cb158d599e3','pages',19,'fe_group','','','',0,0,0,'fe_groups',2,''),('bae35ed610dcc1d73ebc8bd787a11b5d','fe_users',239,'usergroup','','','',0,0,0,'fe_groups',2,''),('bb4103448c7d48c78e169c1cd02f32cd','fe_users',236,'usergroup','','','',0,0,0,'fe_groups',2,''),('bbea86ce5f11307187b6fb15854f7019','fe_users',104,'usergroup','','','',0,0,0,'fe_groups',2,''),('bce1888d41d700d38c7fc7c4efa6c9e5','fe_users',81,'usergroup','','','',0,0,0,'fe_groups',2,''),('bce297ab767a165c065a5b606a796c46','fe_users',45,'usergroup','','','',0,0,0,'fe_groups',2,''),('bd9473b833e142b4919b3dc2319046ef','fe_users',277,'usergroup','','','',0,0,0,'fe_groups',2,''),('bdc1bb157ab6671c5f3ed4e2690b695b','fe_users',485,'usergroup','','','',0,0,0,'fe_groups',2,''),('bdd870b93df97766d7cafaae25df946d','fe_users',777,'usergroup','','','',0,1,0,'fe_groups',2,''),('bee26a846d1556290ce199f3eaa52d12','fe_users',307,'usergroup','','','',0,0,0,'fe_groups',2,''),('bf208690171865c28bbb1abdce405c54','fe_users',544,'usergroup','','','',0,0,0,'fe_groups',2,''),('bf2ba31a1ca7f576132630af0c2f3157','fe_users',787,'usergroup','','','',0,1,0,'fe_groups',2,''),('bfc7e10743b41d75bbded8f1ed4bd7c8','fe_users',753,'usergroup','','','',0,1,0,'fe_groups',2,''),('c032183c0d84a911ea261deeada2fcad','fe_users',758,'usergroup','','','',0,1,0,'fe_groups',2,''),('c0370b3efb65ced02afb872e225d040f','fe_users',414,'usergroup','','','',0,0,0,'fe_groups',2,''),('c0773c896c35820ef4464e8e1ede41b0','fe_users',267,'usergroup','','','',0,0,0,'fe_groups',2,''),('c0f566bc1d27f07fa5db1db5f975950e','fe_users',713,'usergroup','','','',0,1,0,'fe_groups',2,''),('c1b4783aa1f17b0217a8c083436d057d','fe_users',369,'usergroup','','','',0,0,0,'fe_groups',2,''),('c2128e8b98989568802c1b356d2e8b7f','fe_users',150,'usergroup','','','',0,0,0,'fe_groups',2,''),('c2394201a37a78658f169a702d654099','fe_users',794,'usergroup','','','',0,1,0,'fe_groups',2,''),('c291bde7c78930716e0037f9574cebcd','fe_users',478,'usergroup','','','',0,0,0,'fe_groups',2,''),('c29e071dd5c02df98c28be50324814a3','fe_users',41,'usergroup','','','',0,0,0,'fe_groups',2,''),('c2a5fdf62fd16a67fcb904fafac7577e','fe_users',100,'usergroup','','','',0,0,0,'fe_groups',2,''),('c2d18a09ee61b053e6bfe6805a0ae1a9','fe_users',416,'usergroup','','','',0,0,0,'fe_groups',2,''),('c2de545f23a5753e8154a0040b862714','fe_users',516,'usergroup','','','',0,0,0,'fe_groups',2,''),('c2e0e229f2a4e1942ffac89d38653046','fe_users',164,'usergroup','','','',0,0,0,'fe_groups',2,''),('c34a37ff270b7c80d8b95cadad16aef5','fe_users',310,'usergroup','','','',0,0,0,'fe_groups',2,''),('c38451fdf5c631f46f765b49450613f9','fe_users',561,'usergroup','','','',0,0,0,'fe_groups',2,''),('c3b85e9acc1d9a23b9ab1dd50e7f932f','fe_users',768,'usergroup','','','',0,1,0,'fe_groups',2,''),('c4837fbe014ecea085ceca60bc828b35','fe_users',283,'usergroup','','','',0,0,0,'fe_groups',2,''),('c4ccd390e91f93780e962d7a09e5b08d','fe_users',153,'usergroup','','','',0,0,0,'fe_groups',2,''),('c4cd55346a39599e1f34b6517b0784e1','fe_users',144,'usergroup','','','',0,0,0,'fe_groups',2,''),('c4ed4fad2663af228e4bd9180b75e143','fe_users',257,'usergroup','','','',0,0,0,'fe_groups',2,''),('c50582cd66f25d4d96a090d5cbf5fa9d','fe_users',780,'usergroup','','','',0,1,0,'fe_groups',2,''),('c5183188c01cc69633afe304cefa2622','fe_users',486,'usergroup','','','',0,0,0,'fe_groups',2,''),('c56da6dfec991dc140dc898792dc6870','fe_users',329,'usergroup','','','',0,0,0,'fe_groups',2,''),('c616ba64cb43bcd49c8a664d885810e8','fe_users',93,'usergroup','','','',0,0,0,'fe_groups',2,''),('c684634882acd58a79ba62f986b34077','fe_users',732,'usergroup','','','',0,1,0,'fe_groups',2,''),('c6d668ed95fab9d8eaa53864fec5bef2','fe_users',520,'usergroup','','','',0,0,0,'fe_groups',2,''),('c75ab75b92e78adc5bb4090b7d17142b','fe_users',770,'usergroup','','','',0,1,0,'fe_groups',2,''),('c7b123a226de07813d5f2493c6291f85','fe_users',410,'usergroup','','','',0,0,0,'fe_groups',2,''),('c7e36899c8f5253c22303f5dc5f6fb18','fe_users',1,'usergroup','','','',0,1,0,'fe_groups',2,''),('c802c2065596e6cb9b60ba9490b07e73','tt_content',8,'l18n_parent','','','',0,0,0,'tt_content',6,''),('c83785072d200cb8f3d8eff3461696c3','fe_users',538,'usergroup','','','',0,0,0,'fe_groups',2,''),('c90ebf766b3fdf238d0a3b6d8a5e58aa','fe_users',504,'usergroup','','','',0,0,0,'fe_groups',2,''),('c95e71f0951fdd7b2db46ca81dbc0937','fe_users',655,'usergroup','','','',0,1,0,'fe_groups',2,''),('c99871e3d7ff1dbc061016a490a66229','fe_users',162,'usergroup','','','',0,0,0,'fe_groups',2,''),('ca41a3286191574d183f7e34f2d49c6f','fe_users',25,'usergroup','','','',0,0,0,'fe_groups',2,''),('cb7168fb4ecbda8e9396d8f951c7d348','fe_users',374,'usergroup','','','',0,0,0,'fe_groups',2,''),('cbf8f2ae2a053ad7d0520187055d2435','fe_users',446,'usergroup','','','',0,0,0,'fe_groups',2,''),('cbfbe020a19468137bf8fc5b9f9d53d3','fe_users',756,'usergroup','','','',0,1,0,'fe_groups',2,''),('cbfe8a2555795de41b05dfff414e3ee0','fe_users',514,'usergroup','','','',0,0,0,'fe_groups',2,''),('cce121d5e72046a9e655a06576016c58','fe_users',739,'usergroup','','','',0,0,0,'fe_groups',2,''),('cd7902a10115adafb7f96671e532f17e','fe_users',331,'usergroup','','','',0,0,0,'fe_groups',2,''),('cd790ab02fa828fd545e2656c8414b29','fe_users',844,'usergroup','','','',1,0,0,'fe_groups',2,''),('cdbc9dbd384d916dca9e67c5fe9043a0','fe_users',631,'usergroup','','','',0,0,0,'fe_groups',2,''),('cdf46e769cfb4dbd94e695c383af4a96','fe_users',371,'usergroup','','','',0,0,0,'fe_groups',2,''),('ce3d2396cecda6a7384fdeb5a9b52758','fe_users',142,'usergroup','','','',0,0,0,'fe_groups',2,''),('ce997aa9a2b37f47f4732d2f179a84b8','fe_users',555,'usergroup','','','',0,0,0,'fe_groups',2,''),('ceaa327a0e44d120421a9a7b3af6ec00','fe_users',2,'usergroup','','','',0,0,0,'fe_groups',2,''),('ceb5d2ccc3b4d72e3283d8ee54d4bf9b','fe_users',83,'usergroup','','','',0,0,0,'fe_groups',2,''),('cf0ba8ba4ca0b0aca46f012b5e03f3cc','fe_users',409,'usergroup','','','',0,0,0,'fe_groups',2,''),('cf11f746b33bb8fb38e53c6e903f1080','fe_users',568,'usergroup','','','',0,0,0,'fe_groups',2,''),('cf5a9b9f73822b556bb8362070fa879b','fe_users',515,'usergroup','','','',0,0,0,'fe_groups',2,''),('cfc128831a4cfca656754193c26555c5','fe_users',698,'usergroup','','','',0,1,0,'fe_groups',2,''),('cfe276e42e0938836929d474c80b577f','fe_users',633,'usergroup','','','',0,0,0,'fe_groups',2,''),('d0358045cc45a7d6da8d0b80aa35bba3','fe_users',212,'usergroup','','','',0,0,0,'fe_groups',2,''),('d036e81b60238b1961afefb94f9a1663','fe_users',52,'usergroup','','','',0,0,0,'fe_groups',2,''),('d0b21d912ddf99a6ed39a09a48dc8496','fe_users',363,'usergroup','','','',0,0,0,'fe_groups',2,''),('d0fa554ea461140c5cb963e6ea455f21','fe_users',35,'usergroup','','','',0,0,0,'fe_groups',2,''),('d15297b2afa8014904dfbabe8902d090','fe_users',143,'usergroup','','','',0,0,0,'fe_groups',2,''),('d214b97b03aaaaa36dc18aeadc8394f3','fe_users',530,'usergroup','','','',0,0,0,'fe_groups',2,''),('d23ba59f364ecadd7bcc5611f0328ff4','fe_users',84,'usergroup','','','',0,0,0,'fe_groups',2,''),('d23fc37ccefcfd3b3d59fc8e6100c072','fe_users',316,'usergroup','','','',0,0,0,'fe_groups',2,''),('d275b7c0b76bc1db0970de37feabe07f','fe_users',578,'usergroup','','','',0,0,0,'fe_groups',2,''),('d27b70dcce7c554388fd8b9336f19771','fe_users',301,'usergroup','','','',0,0,0,'fe_groups',2,''),('d2e758f6e85639ea3604c9aa97b54ceb','fe_users',763,'usergroup','','','',0,1,0,'fe_groups',2,''),('d2fd6ea9d76bb18d4abfcba4da91a516','fe_users',442,'usergroup','','','',0,0,0,'fe_groups',2,''),('d35c9b52ecd5d55818f2e0d59bb23b01','fe_users',693,'usergroup','','','',0,1,0,'fe_groups',2,''),('d3a8aecf73e4657e5fba08161e2a566e','fe_users',95,'usergroup','','','',0,0,0,'fe_groups',2,''),('d3f99447900c51edec50ec1577c05ee8','fe_users',5,'usergroup','','','',0,0,0,'fe_groups',2,''),('d500408942da071fa95369bfe12ee8d1','fe_users',781,'usergroup','','','',0,1,0,'fe_groups',2,''),('d58222b1155560de28680be01837fdc6','fe_users',791,'usergroup','','','',0,1,0,'fe_groups',2,''),('d66d8476ab623e540e8cc05f84a30af8','fe_users',253,'usergroup','','','',0,0,0,'fe_groups',2,''),('d678f7f7af6b74124b5e644521899be1','fe_users',234,'usergroup','','','',0,0,0,'fe_groups',2,''),('d746abe987d028d34f0f8bbd0dfbc76d','fe_users',744,'usergroup','','','',0,1,0,'fe_groups',2,''),('d79386316b8f7de1369846a102732bf3','fe_users',396,'usergroup','','','',0,0,0,'fe_groups',2,''),('d82985b3ce072d8f0b3559b1122a798c','tt_content',19,'l18n_parent','','','',0,1,0,'tt_content',18,''),('d9025be1eda52be639a06c9a593fc1ad','fe_users',242,'usergroup','','','',0,0,0,'fe_groups',2,''),('d90469324dbe85e3b514d0f14fc4faba','fe_users',723,'usergroup','','','',0,1,0,'fe_groups',2,''),('d915f1ce0687a4c165caf0bcabb5df84','fe_users',583,'usergroup','','','',0,0,0,'fe_groups',2,''),('d92790b9379096e05cf3a2c4041b6c30','fe_users',388,'usergroup','','','',0,0,0,'fe_groups',2,''),('d9332cfa0eaf9a577dfc8bd95fc7b145','fe_users',501,'usergroup','','','',0,0,0,'fe_groups',2,''),('d952d70844f2e87b56b3734193074e98','fe_users',440,'usergroup','','','',0,0,0,'fe_groups',2,''),('da5073c82f276f7ae480bb2ae007d01b','fe_users',748,'usergroup','','','',0,1,0,'fe_groups',2,''),('da636629c38a4a3e0cedcdcec0ba40c1','fe_users',88,'usergroup','','','',0,0,0,'fe_groups',2,''),('da88c4ff5669c884507005b8662db9b0','fe_users',22,'usergroup','','','',0,0,0,'fe_groups',2,''),('dae33ab019aff1f2980537d44d365067','fe_users',337,'usergroup','','','',0,0,0,'fe_groups',2,''),('db42c7d7cddf7461cce027f3f4f06482','fe_users',328,'usergroup','','','',0,0,0,'fe_groups',2,''),('db8b0cb97cc5e10f0cf8331cbb59ffe4','fe_users',79,'usergroup','','','',0,0,0,'fe_groups',2,''),('dbb6a7336db521968ab87a18f1b0a951','fe_users',149,'usergroup','','','',0,0,0,'fe_groups',2,''),('dc14b1143c2a506bfb3140d5e6437a38','fe_users',203,'usergroup','','','',0,0,0,'fe_groups',2,''),('dc1de12281c9d771f2fa4dbc27ae5ae3','fe_users',636,'usergroup','','','',0,0,0,'fe_groups',2,''),('dc2c1b297104f6961e28b195856d5186','fe_users',392,'usergroup','','','',0,0,0,'fe_groups',2,''),('dc579596210bb417b20ad01e61b8d269','fe_users',376,'usergroup','','','',0,0,0,'fe_groups',2,''),('dc84a2269bf5a594074127e9f5997eb0','fe_users',716,'usergroup','','','',0,1,0,'fe_groups',2,''),('dcb6134d6b8ffdfdae69fbd647e81b36','fe_users',647,'usergroup','','','',0,1,0,'fe_groups',2,''),('dce9193259e7190367fd926cdd896037','pages',25,'fe_group','','','',0,0,0,'fe_groups',2,''),('dcecb94c01b56cff22b9d6bc093304c9','fe_users',332,'usergroup','','','',0,0,0,'fe_groups',2,''),('dd14ba8a0f38bca184006f4ddf23b4bf','fe_users',608,'usergroup','','','',0,0,0,'fe_groups',2,''),('dd9ef83f047d94f0bba4e3b80253d07c','fe_users',205,'usergroup','','','',0,0,0,'fe_groups',2,''),('de4236cc4d24bd27c073741651dce5a0','fe_users',673,'usergroup','','','',0,1,0,'fe_groups',2,''),('de50d873ad1c001a0a93f17c60342558','fe_users',809,'usergroup','','','',0,1,0,'fe_groups',2,''),('de9dad13b5bf519612f83bff3df2f7a0','fe_users',737,'usergroup','','','',0,1,0,'fe_groups',2,''),('df2b708214be0cc259781340221390f2','fe_users',507,'usergroup','','','',0,0,0,'fe_groups',2,''),('df3acfc963cd9919da8e7f503d702b59','fe_users',458,'usergroup','','','',0,0,0,'fe_groups',2,''),('df664a8ade042b42bbfdf147ee5198c1','fe_users',309,'usergroup','','','',0,0,0,'fe_groups',2,''),('df7fef663c27c7d2649aafc081e6b58a','fe_users',248,'usergroup','','','',0,0,0,'fe_groups',2,''),('df8b7a0fe24d79e2f4c9ca88750a9d6a','fe_users',109,'usergroup','','','',0,0,0,'fe_groups',2,''),('dff8c3d9e5750334eef7af030baa335a','fe_users',222,'usergroup','','','',0,0,0,'fe_groups',2,''),('e00180764151300e646c8cdefed6a31d','fe_users',784,'usergroup','','','',0,1,0,'fe_groups',2,''),('e061399f2adb5fc7ef420d2a99967060','fe_users',76,'usergroup','','','',0,0,0,'fe_groups',2,''),('e0c7f9262146b2d496fc76b9a4e055dc','fe_users',525,'usergroup','','','',0,0,0,'fe_groups',2,''),('e0d23453693081ee2fd4b0403e10e7f7','fe_users',733,'usergroup','','','',0,1,0,'fe_groups',2,''),('e0fdbc64dccdc4e8107f77f21f7b4b8a','fe_users',542,'usergroup','','','',0,0,0,'fe_groups',2,''),('e313c09a7b58b7c0e7cce6706c56c791','fe_users',540,'usergroup','','','',0,0,0,'fe_groups',2,''),('e3adee6bab2fb4217f2a728861e85cc2','fe_users',70,'usergroup','','','',0,0,0,'fe_groups',2,''),('e3e1f27444d523611690ef98617d223a','fe_users',439,'usergroup','','','',0,0,0,'fe_groups',2,''),('e40b2eaca8a25bd5f1a205fff899fe57','fe_users',775,'usergroup','','','',0,1,0,'fe_groups',2,''),('e44704907e2c33eeeda232eb3a1396a0','fe_users',841,'usergroup','','','',0,0,0,'fe_groups',2,''),('e52d1ab8bbe7fb746baf8fde47cb3d22','fe_users',299,'usergroup','','','',0,0,0,'fe_groups',2,''),('e5b7836b016fcc049b1f579c3f5da4e8','fe_users',686,'usergroup','','','',0,1,0,'fe_groups',2,''),('e6806a4cebcb8f8d4e7a011b754f7eb8','fe_users',658,'usergroup','','','',0,1,0,'fe_groups',2,''),('e68c7f9db838859a445d2ed75001ae81','fe_users',576,'usergroup','','','',0,0,0,'fe_groups',2,''),('e6c21ec6055e24a173ad98faddead5bc','fe_users',506,'usergroup','','','',0,0,0,'fe_groups',2,''),('e6c63a222d5e758384d15a1c88616d03','fe_users',379,'usergroup','','','',0,0,0,'fe_groups',2,''),('e700a0ca01b3ce877da7a3c9b13691a4','fe_users',92,'usergroup','','','',0,0,0,'fe_groups',2,''),('e74da2860a57ca35ab5a416afccdd01b','fe_users',556,'usergroup','','','',0,0,0,'fe_groups',2,''),('e7dbd8d9970942cc74f2b584454b3e53','fe_users',694,'usergroup','','','',0,1,0,'fe_groups',2,''),('e81b499377ee4fe0f0e27b2f7b292c1d','fe_users',53,'usergroup','','','',0,0,0,'fe_groups',2,''),('e85133a5250880f6ee256088a040652b','fe_users',74,'usergroup','','','',0,0,0,'fe_groups',2,''),('e858fef809fda0d200d4776ac85cee47','fe_users',470,'usergroup','','','',0,0,0,'fe_groups',2,''),('e892bbba878540711c404fbc6cc4fafb','fe_users',69,'usergroup','','','',0,0,0,'fe_groups',2,''),('e895cb55d7d2f6c9360a447a3be9e958','fe_users',746,'usergroup','','','',0,1,0,'fe_groups',2,''),('e8a1d7b722d4b043df2b3caa0c9dbad5','fe_users',534,'usergroup','','','',0,0,0,'fe_groups',2,''),('e8ba91a7dba1bbe422c50ea0b025335d','fe_users',558,'usergroup','','','',0,0,0,'fe_groups',2,''),('e8c2d329e5a06dd3661f926c137d19f2','fe_users',626,'usergroup','','','',0,0,0,'fe_groups',2,''),('e959a0f3b60c9ee39df9473693f5d88a','fe_users',367,'usergroup','','','',0,0,0,'fe_groups',2,''),('e9a82e6792afc60e47626a27f6d7af09','fe_users',559,'usergroup','','','',0,0,0,'fe_groups',2,''),('e9d20b8e1b14c17fcb494c1f79513b94','fe_users',589,'usergroup','','','',0,0,0,'fe_groups',2,''),('e9d6fc554154ec5253a1ba0f5c8a0993','fe_users',635,'usergroup','','','',0,0,0,'fe_groups',2,''),('eaef35ba051b48cc920bec8f3953a997','fe_users',170,'usergroup','','','',0,0,0,'fe_groups',2,''),('eb355ae9ce5288ecb074ab2f70037b0b','pages',25,'l10n_parent','','','',0,0,0,'pages',11,''),('eb474476d74f5365812b47ebda8601eb','fe_users',560,'usergroup','','','',0,0,0,'fe_groups',2,''),('eb6dc0a969f74707ba3deb66345a8b50','fe_users',659,'usergroup','','','',0,1,0,'fe_groups',2,''),('ebdb1b424b8530be9644f37a22c5cb78','fe_users',57,'usergroup','','','',0,0,0,'fe_groups',2,''),('ec38ca2bbbd9c081c66e7ea6a9c5450a','fe_users',830,'usergroup','','','',0,1,0,'fe_groups',2,''),('ec7c61eb750121846f143bcd391373b6','fe_users',575,'usergroup','','','',0,0,0,'fe_groups',2,''),('ec7c6db005568a5185809b1592fe50fe','fe_users',276,'usergroup','','','',0,0,0,'fe_groups',2,''),('ec84b55f0431fc8dbeb205f34c61c23b','fe_users',765,'usergroup','','','',0,1,0,'fe_groups',2,''),('ece01116319c90f1b7f5f967c04c9d1b','fe_users',19,'usergroup','','','',0,0,0,'fe_groups',2,''),('ecec1e35b52b2f9d9bac2086b188d9dc','fe_users',463,'usergroup','','','',0,0,0,'fe_groups',2,''),('ed38604c4f87a191f3791ef781bd4fd6','fe_users',370,'usergroup','','','',0,0,0,'fe_groups',2,''),('ed6fb21d5e5c10260dbef2158867d9fa','fe_users',798,'usergroup','','','',0,1,0,'fe_groups',2,''),('ed92da8cfc67931a67f20911a707ab1f','fe_users',298,'usergroup','','','',0,0,0,'fe_groups',2,''),('edb357973376c5e617744e7a5d531e29','fe_users',801,'usergroup','','','',0,1,0,'fe_groups',2,''),('ee1b64f2d6b9fbbf23505cd02c55010b','tt_content',13,'l18n_parent','','','',0,0,0,'tt_content',1,''),('ee6e134a2c68106ebfbe12e09e9794b6','fe_users',840,'usergroup','','','',0,1,0,'fe_groups',2,''),('ee8c0a461db1655ab9e218da99b5c861','fe_users',447,'usergroup','','','',0,0,0,'fe_groups',2,''),('eebfcc44afcd6e66ec109518c3987b42','fe_users',94,'usergroup','','','',0,0,0,'fe_groups',2,''),('ef437fac2306cb796b0d3f01649e8fe8','fe_users',42,'usergroup','','','',0,0,0,'fe_groups',2,''),('efe2df70246d3870eed91951cfd90c47','fe_users',479,'usergroup','','','',0,0,0,'fe_groups',2,''),('f00f18f59f9eb0daa4d4f6590a65054a','fe_users',182,'usergroup','','','',0,0,0,'fe_groups',2,''),('f015cd26cad41d385e4da010a4a6a4d1','fe_users',497,'usergroup','','','',0,0,0,'fe_groups',2,''),('f0dc373f21dbe55fc33ef727b8a144aa','fe_users',87,'usergroup','','','',0,0,0,'fe_groups',2,''),('f1a9afc9349d27c5c38a2ad7c6762a0b','fe_users',124,'usergroup','','','',0,0,0,'fe_groups',2,''),('f22389fe4dc854ce6e2c14cb4ee58f75','fe_users',604,'usergroup','','','',0,0,0,'fe_groups',2,''),('f22531b2324dba74e318b2ba1f67a839','fe_users',500,'usergroup','','','',0,0,0,'fe_groups',2,''),('f24f66bfd33c7650efc150462df9fdf0','fe_users',7,'usergroup','','','',0,0,0,'fe_groups',2,''),('f250993adf09c36e13576a4033d4e983','fe_users',356,'usergroup','','','',0,0,0,'fe_groups',2,''),('f2acc6c3c1184bf5e12b21198045634a','fe_users',335,'usergroup','','','',0,0,0,'fe_groups',2,''),('f308cb4ace5e0306b4c7ea2da378737c','fe_users',569,'usergroup','','','',0,0,0,'fe_groups',2,''),('f398f5c9b5561df35059736410edc21b','fe_users',519,'usergroup','','','',0,0,0,'fe_groups',2,''),('f3c0e1dceba2fe500149e1ea30b65936','fe_users',405,'usergroup','','','',0,0,0,'fe_groups',2,''),('f431a7871084cc81eba7f4e1d73322ad','fe_users',342,'usergroup','','','',0,0,0,'fe_groups',2,''),('f4973ab4687fa7d8982368c8c47a6ae1','fe_users',778,'usergroup','','','',0,1,0,'fe_groups',2,''),('f49ab438c32606baea0d91afed07b98f','fe_users',28,'usergroup','','','',0,0,0,'fe_groups',2,''),('f4f5999121986318ea9f89d7675dfdf4','fe_users',381,'usergroup','','','',0,0,0,'fe_groups',2,''),('f53764fcd3416a814ea727845658601e','fe_users',214,'usergroup','','','',0,0,0,'fe_groups',2,''),('f5547a4fb2090413c7222fa6d9cec8e1','fe_users',238,'usergroup','','','',0,0,0,'fe_groups',2,''),('f61a7312e1e3324a4a0b9e9daad0caaf','fe_users',407,'usergroup','','','',0,0,0,'fe_groups',2,''),('f64d5667c2363c53b065097baa2eb71b','fe_users',524,'usergroup','','','',0,0,0,'fe_groups',2,''),('f66ba380671fd47384efc35ea8b65cd0','fe_users',226,'usergroup','','','',0,0,0,'fe_groups',2,''),('f6a1774809255fdd4ea5a58c914656d0','fe_users',48,'usergroup','','','',0,0,0,'fe_groups',2,''),('f70f2abbebabf683958a3480a95b8dc9','fe_users',678,'usergroup','','','',0,1,0,'fe_groups',2,''),('f70ffa19d7ad2d6dcac26ffb4f7b0cc6','pages',25,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('f7940db8b823852a98777d647cd8d402','fe_users',615,'usergroup','','','',0,0,0,'fe_groups',2,''),('f80a89f03bd6589dcad85d380d1da635','fe_users',172,'usergroup','','','',0,0,0,'fe_groups',2,''),('f8a2567dc0e50de82759fc6e7ede7c6c','fe_users',696,'usergroup','','','',0,1,0,'fe_groups',2,''),('f8fe9ee2b961d215b0dca4f8d61dd7ba','fe_users',466,'usergroup','','','',0,0,0,'fe_groups',2,''),('f92999864e37c9f3709322e3da45f4a9','fe_users',314,'usergroup','','','',0,0,0,'fe_groups',2,''),('f9c70e7c187abb8c85e5519759b58184','fe_users',785,'usergroup','','','',0,1,0,'fe_groups',2,''),('f9f6285819ec8f59c9c9b08d86110870','fe_users',762,'usergroup','','','',0,1,0,'fe_groups',2,''),('fad2d080619c791f3b2326507b35442c','fe_users',468,'usergroup','','','',0,0,0,'fe_groups',2,''),('fb2cdf0d1e6f1fb9c7e482f584d6ac21','fe_users',467,'usergroup','','','',0,0,0,'fe_groups',2,''),('fba3f616ac21ff54985f7e088c99f761','fe_users',344,'usergroup','','','',0,0,0,'fe_groups',2,''),('fbaf36d56cee44848da312da697d2cd2','tt_content',17,'bodytext','','typolink_tag','1',-1,0,0,'_STRING',0,'Generaldirektion@slub-dresden.de'),('fbd3485bc25bb634aa85efbf3e2cedc8','fe_users',134,'usergroup','','','',0,0,0,'fe_groups',2,''),('fbf13067bd9406e4994105df4868cce9','fe_users',304,'usergroup','','','',0,0,0,'fe_groups',2,''),('fc32b2397592208bee052eeb5030a20c','fe_users',623,'usergroup','','','',0,0,0,'fe_groups',2,''),('fc37210bc6871125fc289d95a3cfaef6','fe_users',287,'usergroup','','','',0,0,0,'fe_groups',2,''),('fcd37f7bf275a4f1e4513e7ce23ce15d','fe_users',642,'usergroup','','','',0,0,0,'fe_groups',2,''),('fcf73caa5d07071f73b05a4db7c35ab4','fe_users',782,'usergroup','','','',0,1,0,'fe_groups',2,''),('fd1b736b32eb4fb824dc9370466e67d6','fe_users',178,'usergroup','','','',0,0,0,'fe_groups',2,''),('fd1e678d5927b5870c7d9a8ba1a3f3f0','fe_users',11,'usergroup','','','',0,0,0,'fe_groups',2,''),('fd44ee6628ff90f7ccd1d92eb9bfa468','fe_users',103,'usergroup','','','',0,0,0,'fe_groups',2,''),('fd63bbab2f17d0580eded62008f47d4c','fe_users',725,'usergroup','','','',0,1,0,'fe_groups',2,''),('fdbc6b5ed5ad5c1e13848931538686e9','fe_users',282,'usergroup','','','',0,0,0,'fe_groups',2,''),('fde32d31aed618749819feccc6c22668','fe_users',141,'usergroup','','','',0,0,0,'fe_groups',2,''),('fdf35de8c197a44d81f493df5b7ef2c1','fe_users',652,'usergroup','','','',0,1,0,'fe_groups',2,''),('fe19040c5608fb6e84418c7675e3668d','fe_users',613,'usergroup','','','',0,0,0,'fe_groups',2,''),('fe2ea984afa8bf8dabd9314ac1b87fc9','fe_users',288,'usergroup','','','',0,0,0,'fe_groups',2,''),('fe5f2ef63410f84fd6cac4f3998d1ec5','fe_users',179,'usergroup','','','',0,0,0,'fe_groups',2,''),('feb68a56590cb7b704f23c009735f6cc','fe_users',734,'usergroup','','','',0,1,0,'fe_groups',2,''),('feed57022277bfa4511d5d715adbd094','fe_users',493,'usergroup','','','',0,0,0,'fe_groups',2,''),('feee30db78b7a8af5753470971969e50','fe_users',704,'usergroup','','','',0,1,0,'fe_groups',2,''),('ff036f79f01edaf1917330e8408d3211','fe_users',431,'usergroup','','','',0,0,0,'fe_groups',2,''),('ff037707e4accf5a564bcbf118fe617b','fe_users',454,'usergroup','','','',0,0,0,'fe_groups',2,''),('ffbd22a3a72902a5dc6c62b4603cfcba','fe_users',588,'usergroup','','','',0,0,0,'fe_groups',2,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_key` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=303 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Form\\Hooks\\FormFileExtensionUpdate','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\WizardDoneToRegistry','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\StartModuleUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FrontendUserImageUpdateWizard','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FillTranslationSourceField','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SectionFrameToFrameClassUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SplitMenusUpdate','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BulletContentElementUpdate','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\UploadContentElementUpdate','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFscStaticTemplateUpdate','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FileReferenceUpdate','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFeSessionDataUpdate','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Compatibility7ExtractionUpdate','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FormLegacyExtractionUpdate','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RteHtmlAreaExtractionUpdate','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\LanguageSortingUpdate','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Typo3DbExtractionUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FuncExtractionUpdate','i:1;'),(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateUrlTypesInPagesUpdate','i:1;'),(20,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectExtractionUpdate','i:1;'),(21,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserStartModuleUpdate','i:1;'),(22,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayUpdate','i:1;'),(23,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayBeGroupsAccessRights','i:1;'),(24,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendLayoutIconUpdateWizard','i:1;'),(25,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectsExtensionUpdate','i:1;'),(26,'installUpdate','TYPO3\\CMS\\Install\\Updates\\AdminPanelInstall','i:1;'),(27,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PopulatePageSlugs','i:1;'),(28,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Argon2iPasswordHashes','i:1;'),(29,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserConfigurationUpdate','i:1;'),(30,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),(31,'installUpdateRows','rowUpdatersDone','a:3:{i:0;s:52:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L10nModeUpdater\";i:1;s:53:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\ImageCropUpdater\";i:2;s:57:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\RteLinkSyntaxUpdater\";}'),(32,'extensionDataImport','typo3/sysext/core/ext_tables_static+adt.sql','s:0:\"\";'),(33,'extensionDataImport','typo3/sysext/scheduler/ext_tables_static+adt.sql','s:0:\"\";'),(34,'extensionDataImport','typo3/sysext/extbase/ext_tables_static+adt.sql','s:0:\"\";'),(35,'extensionDataImport','typo3/sysext/fluid/ext_tables_static+adt.sql','s:0:\"\";'),(36,'extensionDataImport','typo3/sysext/frontend/ext_tables_static+adt.sql','s:0:\"\";'),(37,'extensionDataImport','typo3/sysext/fluid_styled_content/ext_tables_static+adt.sql','s:0:\"\";'),(38,'extensionDataImport','typo3/sysext/filelist/ext_tables_static+adt.sql','s:0:\"\";'),(39,'extensionDataImport','typo3/sysext/impexp/ext_tables_static+adt.sql','s:0:\"\";'),(40,'extensionDataImport','typo3/sysext/form/ext_tables_static+adt.sql','s:0:\"\";'),(41,'extensionDataImport','typo3/sysext/install/ext_tables_static+adt.sql','s:0:\"\";'),(42,'extensionDataImport','typo3/sysext/recordlist/ext_tables_static+adt.sql','s:0:\"\";'),(43,'extensionDataImport','typo3/sysext/backend/ext_tables_static+adt.sql','s:0:\"\";'),(44,'extensionDataImport','typo3/sysext/reports/ext_tables_static+adt.sql','s:0:\"\";'),(45,'extensionDataImport','typo3/sysext/setup/ext_tables_static+adt.sql','s:0:\"\";'),(46,'extensionDataImport','typo3/sysext/rte_ckeditor/ext_tables_static+adt.sql','s:0:\"\";'),(47,'extensionDataImport','typo3/sysext/about/ext_tables_static+adt.sql','s:0:\"\";'),(48,'extensionDataImport','typo3/sysext/adminpanel/ext_tables_static+adt.sql','s:0:\"\";'),(49,'extensionDataImport','typo3/sysext/belog/ext_tables_static+adt.sql','s:0:\"\";'),(50,'extensionDataImport','typo3/sysext/beuser/ext_tables_static+adt.sql','s:0:\"\";'),(51,'extensionDataImport','typo3/sysext/extensionmanager/ext_tables_static+adt.sql','s:32:\"9beb0be917f14fdde2c9cb940a47d38e\";'),(52,'extensionDataImport','typo3/sysext/felogin/ext_tables_static+adt.sql','s:0:\"\";'),(53,'extensionDataImport','typo3/sysext/info/ext_tables_static+adt.sql','s:0:\"\";'),(54,'extensionDataImport','typo3/sysext/redirects/ext_tables_static+adt.sql','s:0:\"\";'),(55,'extensionDataImport','typo3/sysext/seo/ext_tables_static+adt.sql','s:0:\"\";'),(56,'extensionDataImport','typo3/sysext/sys_note/ext_tables_static+adt.sql','s:0:\"\";'),(57,'extensionDataImport','typo3/sysext/t3editor/ext_tables_static+adt.sql','s:0:\"\";'),(58,'extensionDataImport','typo3/sysext/tstemplate/ext_tables_static+adt.sql','s:0:\"\";'),(59,'extensionDataImport','typo3/sysext/viewpage/ext_tables_static+adt.sql','s:0:\"\";'),(60,'core','formProtectionSessionToken:1','s:64:\"3f83df962ac2031538747cb7a5cd398d4b0908d0a435137cd26c8028727b38ce\";'),(61,'extensionDataImport','typo3conf/ext/slub_web_kartenforum/ext_tables_static+adt.sql','s:32:\"cd57437a5f633b70b114c94c126c4e1f\";'),(62,'extensionScannerNotAffected','0b69b592c0282cff9221984287598585','s:32:\"0b69b592c0282cff9221984287598585\";'),(64,'extensionScannerNotAffected','e5e622341da70adf63f6d8b8c8e49152','s:32:\"e5e622341da70adf63f6d8b8c8e49152\";'),(65,'extensionScannerNotAffected','bfea06cd79d77e5837f13f835af83116','s:32:\"bfea06cd79d77e5837f13f835af83116\";'),(66,'extensionScannerNotAffected','d94828488045a36bc40849c6f8b195a0','s:32:\"d94828488045a36bc40849c6f8b195a0\";'),(67,'extensionScannerNotAffected','137770a65b8c8d0819b78e386cc37f20','s:32:\"137770a65b8c8d0819b78e386cc37f20\";'),(68,'extensionScannerNotAffected','3800d667a81ea56b0691a0c42e4aa735','s:32:\"3800d667a81ea56b0691a0c42e4aa735\";'),(69,'extensionScannerNotAffected','713ce9cb95953fd15278aad8008700d0','s:32:\"713ce9cb95953fd15278aad8008700d0\";'),(70,'extensionScannerNotAffected','ae91c66cc4e4c53b3ebd277f63618ff3','s:32:\"ae91c66cc4e4c53b3ebd277f63618ff3\";'),(71,'extensionScannerNotAffected','10470ebd96c5d1be6ed052c35e88a572','s:32:\"10470ebd96c5d1be6ed052c35e88a572\";'),(72,'extensionScannerNotAffected','c9198802f9c124c1cb1a1cc0f9b21331','s:32:\"c9198802f9c124c1cb1a1cc0f9b21331\";'),(73,'extensionScannerNotAffected','117f225b4a34c1f605917cb1164b4711','s:32:\"117f225b4a34c1f605917cb1164b4711\";'),(74,'extensionScannerNotAffected','c59521640be26ce42b563af41dc55133','s:32:\"c59521640be26ce42b563af41dc55133\";'),(75,'extensionScannerNotAffected','590492426cf773b2afbc30e44c7cb9a8','s:32:\"590492426cf773b2afbc30e44c7cb9a8\";'),(76,'extensionScannerNotAffected','d3a2b981266c7afc2a62a0706ccd7cc2','s:32:\"d3a2b981266c7afc2a62a0706ccd7cc2\";'),(77,'extensionScannerNotAffected','6afcbbc7b716e87880a5467cf09fbd64','s:32:\"6afcbbc7b716e87880a5467cf09fbd64\";'),(78,'extensionScannerNotAffected','72e9f7b477e14d237e47b6e91ebc552a','s:32:\"72e9f7b477e14d237e47b6e91ebc552a\";'),(79,'extensionScannerNotAffected','f034819b88bc241ff173482a2ae0e3d3','s:32:\"f034819b88bc241ff173482a2ae0e3d3\";'),(80,'extensionScannerNotAffected','aaa9710768df7d8203beffd77d3b3556','s:32:\"aaa9710768df7d8203beffd77d3b3556\";'),(81,'extensionScannerNotAffected','dd5c4bc99a64380b59f54e297e6b0251','s:32:\"dd5c4bc99a64380b59f54e297e6b0251\";'),(82,'extensionScannerNotAffected','9843224e8057c4b0a75986f2b1b0d7de','s:32:\"9843224e8057c4b0a75986f2b1b0d7de\";'),(83,'extensionScannerNotAffected','b0a2e8285534a393b573a86b00d1a17a','s:32:\"b0a2e8285534a393b573a86b00d1a17a\";'),(84,'extensionScannerNotAffected','679b3f7a5f265e78afa52568a7af81ea','s:32:\"679b3f7a5f265e78afa52568a7af81ea\";'),(85,'extensionScannerNotAffected','c7f481de96f5f6eb495f42a328b653f7','s:32:\"c7f481de96f5f6eb495f42a328b653f7\";'),(86,'extensionScannerNotAffected','74d00dbf61e6cf5a5f7db8c5c49e8730','s:32:\"74d00dbf61e6cf5a5f7db8c5c49e8730\";'),(87,'extensionScannerNotAffected','f746fe14df28161312ff6481b765fe6b','s:32:\"f746fe14df28161312ff6481b765fe6b\";'),(88,'extensionScannerNotAffected','a60dfede9467734cd91d13a581ff993d','s:32:\"a60dfede9467734cd91d13a581ff993d\";'),(89,'extensionScannerNotAffected','77e5ec218f56f98dfa21beabdfb470aa','s:32:\"77e5ec218f56f98dfa21beabdfb470aa\";'),(90,'extensionScannerNotAffected','1d36af555ac8264786c3e72a2c251e38','s:32:\"1d36af555ac8264786c3e72a2c251e38\";'),(91,'extensionScannerNotAffected','2727a4091391f76e063b467ebc7f6d86','s:32:\"2727a4091391f76e063b467ebc7f6d86\";'),(92,'extensionScannerNotAffected','58464adfa2c4d03a24ae35dc3f25801c','s:32:\"58464adfa2c4d03a24ae35dc3f25801c\";'),(93,'extensionScannerNotAffected','eb370d58d94c52c8d3a4ee663f37568a','s:32:\"eb370d58d94c52c8d3a4ee663f37568a\";'),(94,'extensionScannerNotAffected','9b7bb233dfb418012c40d31c3fb9752b','s:32:\"9b7bb233dfb418012c40d31c3fb9752b\";'),(95,'extensionScannerNotAffected','e39682b901051ec48ee60fa6cfe12c48','s:32:\"e39682b901051ec48ee60fa6cfe12c48\";'),(96,'extensionScannerNotAffected','2d912704d94dcb07c72395b5d36442b5','s:32:\"2d912704d94dcb07c72395b5d36442b5\";'),(97,'extensionScannerNotAffected','26866dae2f3ba38dfd3487eec1012dce','s:32:\"26866dae2f3ba38dfd3487eec1012dce\";'),(98,'extensionScannerNotAffected','790028fa75f9039383e9d0ebb280e53e','s:32:\"790028fa75f9039383e9d0ebb280e53e\";'),(99,'extensionScannerNotAffected','05f060662b83bd28d7aa26c2f64386ac','s:32:\"05f060662b83bd28d7aa26c2f64386ac\";'),(100,'extensionScannerNotAffected','10a393838d816503c8ce35d6d0d30ed1','s:32:\"10a393838d816503c8ce35d6d0d30ed1\";'),(101,'extensionScannerNotAffected','4255b4e13f24dca784d7ae424348d85d','s:32:\"4255b4e13f24dca784d7ae424348d85d\";'),(102,'extensionScannerNotAffected','2bf671b90e2eb5e6c6b5f9c021354e14','s:32:\"2bf671b90e2eb5e6c6b5f9c021354e14\";'),(103,'extensionScannerNotAffected','2df3bd70753c44a442d988c610324716','s:32:\"2df3bd70753c44a442d988c610324716\";'),(104,'extensionScannerNotAffected','36da4a1ba33eb2b96ed2c0a9e9a51ed7','s:32:\"36da4a1ba33eb2b96ed2c0a9e9a51ed7\";'),(105,'extensionScannerNotAffected','97bc7c077b1b5bfb83a571fa05800762','s:32:\"97bc7c077b1b5bfb83a571fa05800762\";'),(106,'extensionScannerNotAffected','cddb0fb7e5108ed5d6bb3c3952e19af4','s:32:\"cddb0fb7e5108ed5d6bb3c3952e19af4\";'),(107,'extensionScannerNotAffected','33b6736583d84af8775af507206d46ca','s:32:\"33b6736583d84af8775af507206d46ca\";'),(108,'extensionScannerNotAffected','eb9460c6d1a003d9527ce9cf48729e14','s:32:\"eb9460c6d1a003d9527ce9cf48729e14\";'),(109,'extensionScannerNotAffected','f8debb461bd74853fed5bb2961457fa6','s:32:\"f8debb461bd74853fed5bb2961457fa6\";'),(110,'extensionScannerNotAffected','44dacc3b01548666f4f58735c461e0a3','s:32:\"44dacc3b01548666f4f58735c461e0a3\";'),(111,'extensionScannerNotAffected','0334dc151fef8bb6bcaac48afc7044c6','s:32:\"0334dc151fef8bb6bcaac48afc7044c6\";'),(112,'extensionScannerNotAffected','141ccf122c3c7d7fb6b9d6b30ce46faf','s:32:\"141ccf122c3c7d7fb6b9d6b30ce46faf\";'),(113,'extensionScannerNotAffected','77f867e32a06e84b4c1cd0edfe595ce7','s:32:\"77f867e32a06e84b4c1cd0edfe595ce7\";'),(114,'extensionScannerNotAffected','ff5567f61828e66dcdd45a7e864014db','s:32:\"ff5567f61828e66dcdd45a7e864014db\";'),(115,'extensionScannerNotAffected','1ec7fc989b025a9c8356317485bde146','s:32:\"1ec7fc989b025a9c8356317485bde146\";'),(116,'extensionScannerNotAffected','bca64e0231d1758d70893cc3e2457290','s:32:\"bca64e0231d1758d70893cc3e2457290\";'),(117,'extensionScannerNotAffected','306a11d301aef636a577b043a9bc10fa','s:32:\"306a11d301aef636a577b043a9bc10fa\";'),(118,'extensionScannerNotAffected','1daea1177e884f3ea576383e5dac4774','s:32:\"1daea1177e884f3ea576383e5dac4774\";'),(119,'extensionScannerNotAffected','5eba200f09bc23b1b2a0a12bd87926bd','s:32:\"5eba200f09bc23b1b2a0a12bd87926bd\";'),(120,'extensionScannerNotAffected','ac85e53ac53a48d35776941798ab4d76','s:32:\"ac85e53ac53a48d35776941798ab4d76\";'),(121,'extensionScannerNotAffected','d41ca0207dec38e21c9aa3e2091fcb63','s:32:\"d41ca0207dec38e21c9aa3e2091fcb63\";'),(122,'extensionScannerNotAffected','ff5e28aa4ac849a3b1de2225626cadbd','s:32:\"ff5e28aa4ac849a3b1de2225626cadbd\";'),(123,'extensionScannerNotAffected','782a296528be3f95640e8fb1ca72b61b','s:32:\"782a296528be3f95640e8fb1ca72b61b\";'),(124,'extensionScannerNotAffected','388a9b5cf2dc024abce1ccda0c00666b','s:32:\"388a9b5cf2dc024abce1ccda0c00666b\";'),(125,'extensionScannerNotAffected','3af67f0226440b92916c9ac47ecc0f45','s:32:\"3af67f0226440b92916c9ac47ecc0f45\";'),(126,'extensionScannerNotAffected','538801047ed609227d9cf1ff6302f69d','s:32:\"538801047ed609227d9cf1ff6302f69d\";'),(127,'extensionScannerNotAffected','39927fae0bdc126decd803df9975697b','s:32:\"39927fae0bdc126decd803df9975697b\";'),(128,'extensionScannerNotAffected','2de6f2010831b2dbebe1c566382968d9','s:32:\"2de6f2010831b2dbebe1c566382968d9\";'),(129,'extensionScannerNotAffected','dd717b8dee96d5b999879b4de8d35ec5','s:32:\"dd717b8dee96d5b999879b4de8d35ec5\";'),(130,'extensionScannerNotAffected','144cc46f4036b271da85fa68c7e31ec6','s:32:\"144cc46f4036b271da85fa68c7e31ec6\";'),(131,'extensionScannerNotAffected','53f2e9f92611d61893d2d1b9d2131d15','s:32:\"53f2e9f92611d61893d2d1b9d2131d15\";'),(132,'extensionScannerNotAffected','8181fb86d49358beab7d215f40f9b9d0','s:32:\"8181fb86d49358beab7d215f40f9b9d0\";'),(133,'extensionScannerNotAffected','ad00c9bfc110d595723c667ef024d8e9','s:32:\"ad00c9bfc110d595723c667ef024d8e9\";'),(134,'extensionScannerNotAffected','1476ca2c06acc6b6cb8bac78b0633bf6','s:32:\"1476ca2c06acc6b6cb8bac78b0633bf6\";'),(135,'extensionScannerNotAffected','a59be9db96adc138df8439284a35f1b1','s:32:\"a59be9db96adc138df8439284a35f1b1\";'),(136,'extensionScannerNotAffected','c2cb531b3769bfe93d36c2d6a43a436a','s:32:\"c2cb531b3769bfe93d36c2d6a43a436a\";'),(137,'extensionScannerNotAffected','ff0771e45e03394ed17c8783e5e083d6','s:32:\"ff0771e45e03394ed17c8783e5e083d6\";'),(138,'extensionScannerNotAffected','6b28fe44430f57ad36119ad15d1aed79','s:32:\"6b28fe44430f57ad36119ad15d1aed79\";'),(139,'extensionScannerNotAffected','b53560dfb6ad7c0d067ec228b9d158d6','s:32:\"b53560dfb6ad7c0d067ec228b9d158d6\";'),(140,'extensionScannerNotAffected','a2541c8ae57e07e86192ed8cc132718a','s:32:\"a2541c8ae57e07e86192ed8cc132718a\";'),(141,'extensionScannerNotAffected','e145f6079b7f9d0ec06e99a2b076c0a8','s:32:\"e145f6079b7f9d0ec06e99a2b076c0a8\";'),(142,'extensionScannerNotAffected','2d7e49260d1feaedd48d810213ffb538','s:32:\"2d7e49260d1feaedd48d810213ffb538\";'),(143,'extensionScannerNotAffected','f8089f0f8d3e9e2f1dd88d3908eb6e75','s:32:\"f8089f0f8d3e9e2f1dd88d3908eb6e75\";'),(144,'extensionScannerNotAffected','66ed9c10913b6a895e8f53f17d242d2a','s:32:\"66ed9c10913b6a895e8f53f17d242d2a\";'),(145,'extensionScannerNotAffected','da4784251913511a4be69adb66dc6248','s:32:\"da4784251913511a4be69adb66dc6248\";'),(146,'extensionScannerNotAffected','181fece53aa7b13396193738a08ab7a5','s:32:\"181fece53aa7b13396193738a08ab7a5\";'),(147,'extensionScannerNotAffected','606a1ff02c65e772c51feaa1ea681234','s:32:\"606a1ff02c65e772c51feaa1ea681234\";'),(148,'extensionScannerNotAffected','95a788a9e8bdf766bb7b24c46f66589b','s:32:\"95a788a9e8bdf766bb7b24c46f66589b\";'),(149,'extensionScannerNotAffected','fd1adc61cb6d986a3e7a4dd65609fcba','s:32:\"fd1adc61cb6d986a3e7a4dd65609fcba\";'),(150,'extensionScannerNotAffected','dcabdff470c575a8ed319d14fb9c424f','s:32:\"dcabdff470c575a8ed319d14fb9c424f\";'),(151,'extensionScannerNotAffected','9db18807754661411e84d91946f6c47b','s:32:\"9db18807754661411e84d91946f6c47b\";'),(152,'extensionScannerNotAffected','e76d8583899c660d9b8f059f1e70b398','s:32:\"e76d8583899c660d9b8f059f1e70b398\";'),(153,'extensionScannerNotAffected','aea1390a84313285af1f87cb50d8213e','s:32:\"aea1390a84313285af1f87cb50d8213e\";'),(154,'extensionScannerNotAffected','9fe318e826cbedb8fd1a26941d19005a','s:32:\"9fe318e826cbedb8fd1a26941d19005a\";'),(155,'extensionScannerNotAffected','08f23e8308e19cd3b730c99b5724f918','s:32:\"08f23e8308e19cd3b730c99b5724f918\";'),(156,'extensionScannerNotAffected','0a6f2835e55a235c905a1705df41cee7','s:32:\"0a6f2835e55a235c905a1705df41cee7\";'),(157,'extensionScannerNotAffected','97d8364d14683e5c99cf3d61d245757b','s:32:\"97d8364d14683e5c99cf3d61d245757b\";'),(158,'extensionScannerNotAffected','96c7a3f1fc0fe11bcdc7115a31b16f93','s:32:\"96c7a3f1fc0fe11bcdc7115a31b16f93\";'),(159,'extensionScannerNotAffected','d70cecc33fb1c59414665bc6865b8684','s:32:\"d70cecc33fb1c59414665bc6865b8684\";'),(160,'extensionScannerNotAffected','dd4f137389ebdeacaae2a4dec7d17993','s:32:\"dd4f137389ebdeacaae2a4dec7d17993\";'),(161,'extensionScannerNotAffected','7ca777fd910da99f301f8d6791dd8477','s:32:\"7ca777fd910da99f301f8d6791dd8477\";'),(162,'extensionScannerNotAffected','9f6b69352cc9437112c62aa2b5543692','s:32:\"9f6b69352cc9437112c62aa2b5543692\";'),(163,'extensionScannerNotAffected','72dcabf4098f87f91ffbd0680358d214','s:32:\"72dcabf4098f87f91ffbd0680358d214\";'),(164,'extensionScannerNotAffected','543adcda9a07c1be6be6863f4fc3de89','s:32:\"543adcda9a07c1be6be6863f4fc3de89\";'),(165,'extensionScannerNotAffected','d209ef32995636ed8252c304366460f0','s:32:\"d209ef32995636ed8252c304366460f0\";'),(166,'extensionScannerNotAffected','f9d942cb02be7865d4818bda14172e5e','s:32:\"f9d942cb02be7865d4818bda14172e5e\";'),(167,'extensionScannerNotAffected','83d762e1a46c1363d7f5fabf77da2db4','s:32:\"83d762e1a46c1363d7f5fabf77da2db4\";'),(168,'extensionScannerNotAffected','9be17234d688f35a777c9476d9f3c71b','s:32:\"9be17234d688f35a777c9476d9f3c71b\";'),(169,'extensionScannerNotAffected','e64f98e82453cb5e4ddcea3fbb6ea1f8','s:32:\"e64f98e82453cb5e4ddcea3fbb6ea1f8\";'),(170,'extensionScannerNotAffected','6e37d32633631b068e06299c8acffee3','s:32:\"6e37d32633631b068e06299c8acffee3\";'),(171,'extensionScannerNotAffected','27ab68dff32c68264a8f5052ce2bfa39','s:32:\"27ab68dff32c68264a8f5052ce2bfa39\";'),(172,'extensionScannerNotAffected','6539b2eef11f6335580d5c96f1ba17de','s:32:\"6539b2eef11f6335580d5c96f1ba17de\";'),(173,'extensionScannerNotAffected','a767d6a06ae489ffffd6c26bc25fb38a','s:32:\"a767d6a06ae489ffffd6c26bc25fb38a\";'),(174,'extensionScannerNotAffected','cbd21e7f03086cafbdc9e29aca0d7de9','s:32:\"cbd21e7f03086cafbdc9e29aca0d7de9\";'),(175,'extensionScannerNotAffected','bd3841546ff3c306e782b477cda497f0','s:32:\"bd3841546ff3c306e782b477cda497f0\";'),(176,'extensionScannerNotAffected','986062b4896ff2cd9eece3eef4ded45b','s:32:\"986062b4896ff2cd9eece3eef4ded45b\";'),(177,'extensionScannerNotAffected','b86bf8233a9c62ebca0cacff2f89d5e3','s:32:\"b86bf8233a9c62ebca0cacff2f89d5e3\";'),(178,'extensionScannerNotAffected','858a87554a870c3f8cba49b81e5fc3a3','s:32:\"858a87554a870c3f8cba49b81e5fc3a3\";'),(179,'extensionScannerNotAffected','0401d8602099bcafdbdffb88a96a7a3c','s:32:\"0401d8602099bcafdbdffb88a96a7a3c\";'),(180,'extensionScannerNotAffected','40e5025c405909578400ab83e7761b74','s:32:\"40e5025c405909578400ab83e7761b74\";'),(181,'extensionScannerNotAffected','bf64fd0e3399cba335ba6da86212a590','s:32:\"bf64fd0e3399cba335ba6da86212a590\";'),(182,'extensionScannerNotAffected','846385e26abb209c7484fae2f0e714a4','s:32:\"846385e26abb209c7484fae2f0e714a4\";'),(183,'extensionScannerNotAffected','f7cc244676b74f17ca6bdb46707637f4','s:32:\"f7cc244676b74f17ca6bdb46707637f4\";'),(184,'extensionScannerNotAffected','97459c0367812d1fb78d00f024ff20aa','s:32:\"97459c0367812d1fb78d00f024ff20aa\";'),(185,'extensionScannerNotAffected','ec85f46288965aa648ce9a1e37f2b58a','s:32:\"ec85f46288965aa648ce9a1e37f2b58a\";'),(186,'extensionScannerNotAffected','ba01e41c82b0218933f2c05542aec142','s:32:\"ba01e41c82b0218933f2c05542aec142\";'),(187,'extensionScannerNotAffected','8bcdcb5cb360544051b268949bfe5793','s:32:\"8bcdcb5cb360544051b268949bfe5793\";'),(188,'extensionScannerNotAffected','d8ddb8d308daf783e702d6ff4197b630','s:32:\"d8ddb8d308daf783e702d6ff4197b630\";'),(189,'extensionScannerNotAffected','2b495b045a49a5002f033f663268e460','s:32:\"2b495b045a49a5002f033f663268e460\";'),(190,'extensionScannerNotAffected','07be8a5d35d670955b5edd1cf6fb177e','s:32:\"07be8a5d35d670955b5edd1cf6fb177e\";'),(191,'extensionScannerNotAffected','c526c9a91d824901b33106452ac6e8ed','s:32:\"c526c9a91d824901b33106452ac6e8ed\";'),(192,'extensionScannerNotAffected','da20688d2c914dfbb71b99797a2b5231','s:32:\"da20688d2c914dfbb71b99797a2b5231\";'),(193,'extensionScannerNotAffected','8e787af732d7f3edea4492626092bfb4','s:32:\"8e787af732d7f3edea4492626092bfb4\";'),(194,'extensionScannerNotAffected','329a78b9a0cb7a8fce549d1f99750626','s:32:\"329a78b9a0cb7a8fce549d1f99750626\";'),(195,'extensionScannerNotAffected','db580c43603bc85dce820925c0391148','s:32:\"db580c43603bc85dce820925c0391148\";'),(196,'extensionScannerNotAffected','d544bdbde714a2ec968cb3270273fc18','s:32:\"d544bdbde714a2ec968cb3270273fc18\";'),(197,'extensionScannerNotAffected','91ea87d2b06ea4f647e043148d951c52','s:32:\"91ea87d2b06ea4f647e043148d951c52\";'),(198,'extensionScannerNotAffected','94935c6e14d0aff251bb66552a78774e','s:32:\"94935c6e14d0aff251bb66552a78774e\";'),(199,'extensionScannerNotAffected','c7d2136d519fa26627008c5c7ef0b7b8','s:32:\"c7d2136d519fa26627008c5c7ef0b7b8\";'),(200,'extensionScannerNotAffected','dfaf4db240d3f4883278b2f285c5607e','s:32:\"dfaf4db240d3f4883278b2f285c5607e\";'),(201,'extensionScannerNotAffected','f55d0a8bf02260a90d0dfd562fd3011f','s:32:\"f55d0a8bf02260a90d0dfd562fd3011f\";'),(202,'extensionScannerNotAffected','65d3c5339cf7b511f4f892427a5a294f','s:32:\"65d3c5339cf7b511f4f892427a5a294f\";'),(203,'extensionScannerNotAffected','7bf45c02a5c39c6babccb5ea80a820ac','s:32:\"7bf45c02a5c39c6babccb5ea80a820ac\";'),(204,'extensionScannerNotAffected','8e57538a6b4eb5977b710dda86c19a79','s:32:\"8e57538a6b4eb5977b710dda86c19a79\";'),(205,'extensionScannerNotAffected','9522a14ae76b26966c6383c435872cf2','s:32:\"9522a14ae76b26966c6383c435872cf2\";'),(206,'extensionScannerNotAffected','747e64fff64dd7432e84a08fe738067a','s:32:\"747e64fff64dd7432e84a08fe738067a\";'),(207,'extensionScannerNotAffected','97f1cb270f7c6ce7261e229007892f53','s:32:\"97f1cb270f7c6ce7261e229007892f53\";'),(208,'extensionScannerNotAffected','8d99ace37d1d1b36fbab3a9d6304e918','s:32:\"8d99ace37d1d1b36fbab3a9d6304e918\";'),(209,'extensionScannerNotAffected','3ea2e88429bdcbbd9cfe70d1705d0823','s:32:\"3ea2e88429bdcbbd9cfe70d1705d0823\";'),(210,'extensionScannerNotAffected','e009576208e2478646761c31e62ffff8','s:32:\"e009576208e2478646761c31e62ffff8\";'),(211,'extensionScannerNotAffected','1c5a05a66768940687520074a52c2d99','s:32:\"1c5a05a66768940687520074a52c2d99\";'),(212,'extensionScannerNotAffected','b6058a0dc990a2c719ebaf093f5fc02f','s:32:\"b6058a0dc990a2c719ebaf093f5fc02f\";'),(213,'extensionScannerNotAffected','033478cb9a9fad54909d24c48f2fbee8','s:32:\"033478cb9a9fad54909d24c48f2fbee8\";'),(214,'extensionScannerNotAffected','66917c534366520df96a319aa595aadf','s:32:\"66917c534366520df96a319aa595aadf\";'),(215,'extensionScannerNotAffected','407bdf75e994d5e754cd62fe949c9e9b','s:32:\"407bdf75e994d5e754cd62fe949c9e9b\";'),(216,'extensionScannerNotAffected','eace7e4de80cf7847b30899b5c647e01','s:32:\"eace7e4de80cf7847b30899b5c647e01\";'),(217,'extensionScannerNotAffected','67442386f8c3115084d1214937e3b4a8','s:32:\"67442386f8c3115084d1214937e3b4a8\";'),(218,'extensionScannerNotAffected','09d630c80626c1b76089fcc5c01a6ebb','s:32:\"09d630c80626c1b76089fcc5c01a6ebb\";'),(219,'extensionScannerNotAffected','515ba3726a1dfded6ef6b83d1581ec83','s:32:\"515ba3726a1dfded6ef6b83d1581ec83\";'),(220,'extensionScannerNotAffected','3f8faefc1fe5b54d8903efdfee5ac291','s:32:\"3f8faefc1fe5b54d8903efdfee5ac291\";'),(221,'extensionScannerNotAffected','84958529cec39361876616e3725c4f9b','s:32:\"84958529cec39361876616e3725c4f9b\";'),(222,'extensionScannerNotAffected','256574d860279e77e16ec42976515826','s:32:\"256574d860279e77e16ec42976515826\";'),(223,'extensionScannerNotAffected','a2da539b9ee347a8e042edfaf888d512','s:32:\"a2da539b9ee347a8e042edfaf888d512\";'),(224,'extensionScannerNotAffected','27cb6bf0a45fb36cd7ac73a2c0a572ef','s:32:\"27cb6bf0a45fb36cd7ac73a2c0a572ef\";'),(225,'extensionScannerNotAffected','aeba5d0706fd347bdc5272f996118fea','s:32:\"aeba5d0706fd347bdc5272f996118fea\";'),(226,'extensionScannerNotAffected','c406c1b4bb1a5dfd9c08d4559bb8e8ee','s:32:\"c406c1b4bb1a5dfd9c08d4559bb8e8ee\";'),(227,'extensionScannerNotAffected','e872218b822e4a3de6e5ae039fdd2f60','s:32:\"e872218b822e4a3de6e5ae039fdd2f60\";'),(228,'extensionScannerNotAffected','c5dd6f8903c59d422e06f980e5b36552','s:32:\"c5dd6f8903c59d422e06f980e5b36552\";'),(229,'extensionScannerNotAffected','7160b22e95d6e92862b7761a18a21cb9','s:32:\"7160b22e95d6e92862b7761a18a21cb9\";'),(230,'extensionScannerNotAffected','19376586fba8888a27efd8af6a4583cf','s:32:\"19376586fba8888a27efd8af6a4583cf\";'),(231,'extensionScannerNotAffected','23bb7c19b079c8fe437d78e2e66364e8','s:32:\"23bb7c19b079c8fe437d78e2e66364e8\";'),(232,'extensionScannerNotAffected','0d9fbf4a461435c9eeedb3cc130dace5','s:32:\"0d9fbf4a461435c9eeedb3cc130dace5\";'),(233,'extensionScannerNotAffected','71ebec4960c1b84c199c5a33277b084d','s:32:\"71ebec4960c1b84c199c5a33277b084d\";'),(234,'extensionScannerNotAffected','a1ff42bfe65aa2a7250e8ef7e195bcd5','s:32:\"a1ff42bfe65aa2a7250e8ef7e195bcd5\";'),(235,'extensionScannerNotAffected','c7bfdc48f32344ba1d1ae63f65de7271','s:32:\"c7bfdc48f32344ba1d1ae63f65de7271\";'),(236,'extensionScannerNotAffected','a8b76974d80653cd9d3e19cf8fbbc54d','s:32:\"a8b76974d80653cd9d3e19cf8fbbc54d\";'),(237,'extensionScannerNotAffected','13d6f701b41fb36f0e0083a22bb85002','s:32:\"13d6f701b41fb36f0e0083a22bb85002\";'),(238,'extensionScannerNotAffected','b1ab184e4a9874ce5e04c374155c7f03','s:32:\"b1ab184e4a9874ce5e04c374155c7f03\";'),(239,'extensionScannerNotAffected','e41e345fdcabb5d16cf9cbcaf5f6770c','s:32:\"e41e345fdcabb5d16cf9cbcaf5f6770c\";'),(240,'extensionScannerNotAffected','c0a7d44f061cb4c2deca56a6ce548669','s:32:\"c0a7d44f061cb4c2deca56a6ce548669\";'),(241,'extensionScannerNotAffected','02a805a392483b732732f93901406ceb','s:32:\"02a805a392483b732732f93901406ceb\";'),(242,'extensionScannerNotAffected','4fdf992e0b9d01d8b36830baffa7e987','s:32:\"4fdf992e0b9d01d8b36830baffa7e987\";'),(243,'extensionScannerNotAffected','b6955ff14a49b23c4b55a16ceda2f53f','s:32:\"b6955ff14a49b23c4b55a16ceda2f53f\";'),(244,'extensionScannerNotAffected','2c3b83bfc1f271ba9a860c00e99d9b6f','s:32:\"2c3b83bfc1f271ba9a860c00e99d9b6f\";'),(245,'extensionScannerNotAffected','e1a09d1fd8685d6062cf3e7799e126f9','s:32:\"e1a09d1fd8685d6062cf3e7799e126f9\";'),(246,'extensionScannerNotAffected','aee3aa4544e3318e32219407712cce1c','s:32:\"aee3aa4544e3318e32219407712cce1c\";'),(247,'extensionScannerNotAffected','07123938cdaa13ee58f25d01cc26690b','s:32:\"07123938cdaa13ee58f25d01cc26690b\";'),(248,'extensionScannerNotAffected','397c9a4bcca973b3b451be07aae2d85d','s:32:\"397c9a4bcca973b3b451be07aae2d85d\";'),(249,'extensionScannerNotAffected','b75fd56db65b57134ee3a392333164e6','s:32:\"b75fd56db65b57134ee3a392333164e6\";'),(250,'extensionScannerNotAffected','bb9a966a09e9ef5a034900a4bca6ef96','s:32:\"bb9a966a09e9ef5a034900a4bca6ef96\";'),(251,'extensionScannerNotAffected','bd1929903ae77d7a33efa0feb711cfb6','s:32:\"bd1929903ae77d7a33efa0feb711cfb6\";'),(252,'extensionScannerNotAffected','e164383a65972e81d1d4ceed1b787c5c','s:32:\"e164383a65972e81d1d4ceed1b787c5c\";'),(253,'extensionScannerNotAffected','54278669581b9b9898c259be1c1d0e91','s:32:\"54278669581b9b9898c259be1c1d0e91\";'),(254,'extensionScannerNotAffected','6366dd14c672aa71ebf03205723f68a2','s:32:\"6366dd14c672aa71ebf03205723f68a2\";'),(255,'extensionScannerNotAffected','d1e1110b267f6c82aac369fe44d1026f','s:32:\"d1e1110b267f6c82aac369fe44d1026f\";'),(256,'extensionScannerNotAffected','5f19c061916be2a684833b270fd025ff','s:32:\"5f19c061916be2a684833b270fd025ff\";'),(257,'extensionScannerNotAffected','09e682d75e634e3ceb0f7f98527b1505','s:32:\"09e682d75e634e3ceb0f7f98527b1505\";'),(258,'extensionScannerNotAffected','16aab8758e3be9a5eae25ab0ffc9ac50','s:32:\"16aab8758e3be9a5eae25ab0ffc9ac50\";'),(259,'extensionScannerNotAffected','5dfdf6cf1184deae70be20b67437408a','s:32:\"5dfdf6cf1184deae70be20b67437408a\";'),(260,'extensionScannerNotAffected','5e3556a907f7c423702aafe5bd21283b','s:32:\"5e3556a907f7c423702aafe5bd21283b\";'),(261,'extensionScannerNotAffected','37263679ea002b67d6c926e96199e0cb','s:32:\"37263679ea002b67d6c926e96199e0cb\";'),(262,'extensionScannerNotAffected','12b246daad701f9511c661587d1f4e6a','s:32:\"12b246daad701f9511c661587d1f4e6a\";'),(263,'extensionScannerNotAffected','491537cef95923e1e1df8619a5bd9924','s:32:\"491537cef95923e1e1df8619a5bd9924\";'),(264,'extensionScannerNotAffected','0aaa78219033da9093ecded3a045d686','s:32:\"0aaa78219033da9093ecded3a045d686\";'),(265,'extensionScannerNotAffected','e5fefe9c0e303befc6e3587e6015bd5f','s:32:\"e5fefe9c0e303befc6e3587e6015bd5f\";'),(266,'extensionScannerNotAffected','150c7c72278375a02383fdf867b9a14e','s:32:\"150c7c72278375a02383fdf867b9a14e\";'),(267,'extensionScannerNotAffected','63052e9b8451752e184e2d932bc7dd62','s:32:\"63052e9b8451752e184e2d932bc7dd62\";'),(268,'extensionScannerNotAffected','0de71175cd69f6922e46015ac1646084','s:32:\"0de71175cd69f6922e46015ac1646084\";'),(269,'extensionScannerNotAffected','3a288da8230d042aa0fefe3c9d010fc9','s:32:\"3a288da8230d042aa0fefe3c9d010fc9\";'),(270,'extensionScannerNotAffected','ded4b923244fe03a0ba7a483e8000813','s:32:\"ded4b923244fe03a0ba7a483e8000813\";'),(271,'extensionScannerNotAffected','b4310ab842bd0c4c910ee09f20037987','s:32:\"b4310ab842bd0c4c910ee09f20037987\";'),(272,'extensionScannerNotAffected','f4592d107f1f59a157f6c116814480fe','s:32:\"f4592d107f1f59a157f6c116814480fe\";'),(273,'extensionScannerNotAffected','4fb09912c38414756af594202cb2f690','s:32:\"4fb09912c38414756af594202cb2f690\";'),(274,'extensionScannerNotAffected','4579e1fbe7c94b5510b7796b672c2d80','s:32:\"4579e1fbe7c94b5510b7796b672c2d80\";'),(275,'extensionScannerNotAffected','bf0cb1ebffe995bc39723cb13738ea6a','s:32:\"bf0cb1ebffe995bc39723cb13738ea6a\";'),(276,'extensionScannerNotAffected','7f95a3579a446aecec1217a456433f0f','s:32:\"7f95a3579a446aecec1217a456433f0f\";'),(277,'extensionScannerNotAffected','e307efdd6ecb8c3fd0bea412d0a0db1c','s:32:\"e307efdd6ecb8c3fd0bea412d0a0db1c\";'),(278,'extensionScannerNotAffected','0bee48ca87fa9b61a2a7047f53e638d9','s:32:\"0bee48ca87fa9b61a2a7047f53e638d9\";'),(279,'extensionScannerNotAffected','0d60eaef00c478199d475ca60d7340c7','s:32:\"0d60eaef00c478199d475ca60d7340c7\";'),(280,'extensionScannerNotAffected','31eabeee23cfbd2e810ec7163f298fe2','s:32:\"31eabeee23cfbd2e810ec7163f298fe2\";'),(281,'extensionScannerNotAffected','3b082c2f15d19c95a2274f2f9cf67936','s:32:\"3b082c2f15d19c95a2274f2f9cf67936\";'),(282,'extensionScannerNotAffected','3eae74ce8bf1dda88a3956580f0ee095','s:32:\"3eae74ce8bf1dda88a3956580f0ee095\";'),(283,'extensionScannerNotAffected','aab92a3622f423c5bf6364e4b3720433','s:32:\"aab92a3622f423c5bf6364e4b3720433\";'),(284,'extensionScannerNotAffected','00d7d3a7bb4187e3a130a8207ce29332','s:32:\"00d7d3a7bb4187e3a130a8207ce29332\";'),(285,'extensionScannerNotAffected','51e7b5cfb13385843bcf4db3f3d80824','s:32:\"51e7b5cfb13385843bcf4db3f3d80824\";'),(286,'extensionScannerNotAffected','7f24f3339010d86836d49812532da677','s:32:\"7f24f3339010d86836d49812532da677\";'),(287,'extensionScannerNotAffected','7053139b178834fc4832de6ef3bb35e4','s:32:\"7053139b178834fc4832de6ef3bb35e4\";'),(288,'extensionScannerNotAffected','0f72ecbde01e66ab8de6cda9f6ff6031','s:32:\"0f72ecbde01e66ab8de6cda9f6ff6031\";'),(289,'extensionScannerNotAffected','4a1ffb6acbac6b2a1330dec6a118e9b7','s:32:\"4a1ffb6acbac6b2a1330dec6a118e9b7\";'),(290,'extensionScannerNotAffected','4446e163f2527d13cef9b690a59d41a0','s:32:\"4446e163f2527d13cef9b690a59d41a0\";'),(291,'extensionScannerNotAffected','cc57748e8798b0147782cf3a9e868015','s:32:\"cc57748e8798b0147782cf3a9e868015\";'),(292,'extensionScannerNotAffected','7591886b875efd00b894eb60256ac0e9','s:32:\"7591886b875efd00b894eb60256ac0e9\";'),(293,'extensionScannerNotAffected','e1d1b139beff6b083fab80e2e6604a86','s:32:\"e1d1b139beff6b083fab80e2e6604a86\";'),(294,'extensionScannerNotAffected','5d6acfcf63df912878a53dfb4f88f66c','s:32:\"5d6acfcf63df912878a53dfb4f88f66c\";'),(295,'extensionScannerNotAffected','6325e8f1bf6ee47776eec4aa896ae498','s:32:\"6325e8f1bf6ee47776eec4aa896ae498\";'),(296,'extensionScannerNotAffected','c310acb623b8c522450745fddb89a18b','s:32:\"c310acb623b8c522450745fddb89a18b\";'),(297,'extensionScannerNotAffected','244de3e3bf16bd6ecc7abdd9f5134baa','s:32:\"244de3e3bf16bd6ecc7abdd9f5134baa\";'),(298,'extensionScannerNotAffected','e644b224460392561dd815bddc13e280','s:32:\"e644b224460392561dd815bddc13e280\";'),(299,'extensionScannerNotAffected','dc4027985e6fc1e36977379ef3f9dcf3','s:32:\"dc4027985e6fc1e36977379ef3f9dcf3\";'),(300,'extensionScannerNotAffected','8c0a471eb1e62a9df7e2a0ab710144ab','s:32:\"8c0a471eb1e62a9df7e2a0ab710144ab\";'),(301,'extensionScannerNotAffected','2dec44f31d4d8868fe0fafe592b1c93e','s:32:\"2dec44f31d4d8868fe0fafe592b1c93e\";'),(302,'extensionScannerNotAffected','f7ffff32fb53be1a4f44895e1468fef1','s:32:\"f7ffff32fb53be1a4f44895e1468fef1\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sitetitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `constants` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedOn` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,1,1639728435,1631521078,1,0,0,0,0,256,NULL,0,0,0,0,0,0,0,0,'NEUE WEBSITE','Virtuelles Kartenforum',1,3,'EXT:fluid_styled_content/Configuration/TypoScript/,EXT:slub_web_kartenforum/Configuration/TypoScript','config.welcomePage = 5\r\nconfig.loginPage = 6\r\nconfig.menuMeta = 29\r\nconfig.georefhistoryPage = 11\r\nconfig.georefchoosePage = 19\r\nconfig.evaluationPage = 0\r\nconfig.userStoragePid = 8\r\nconfig.georef.backend = http://sdvvk20geo.slub-dresden.de/georeference\r\nconfig.rootPageId = 1\r\nconfig.georefPage = 20\r\nconfig.baseUrl = https://ddev-kartenforum.ddev.site/\r\nconfig.elasticsearch.node = https://kartenforum.slub-dresden.de/spatialdocuments','config.contentObjectExceptionHandler = 0\r\nconfig.no_cache = 1','',0,0,1);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `CType` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `space_after_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `records` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pages` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `list_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date` int(10) unsigned NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `accessibility_title` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `selected_categories` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_caption` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,'',6,1641561196,1631521078,1,0,0,0,0,'',128,0,0,0,0,NULL,0,'a:23:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:11:\"pi_flexform\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'felogin_login','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"showForgotPassword\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"showPermaLogin\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"showLogoutFormAfterLogin\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"pages\">\n                    <value index=\"vDEF\">8</value>\n                </field>\n                <field index=\"recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.showForgotPassword\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showPermaLogin\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.showLogoutFormAfterLogin\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.pages\">\n                    <value index=\"vDEF\">8</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_redirect\">\n            <language index=\"lDEF\">\n                <field index=\"redirectMode\">\n                    <value index=\"vDEF\">login,referer,logout</value>\n                </field>\n                <field index=\"redirectFirstMethod\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"redirectPageLogin\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"redirectPageLoginError\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"redirectPageLogout\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"redirectDisable\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.redirectMode\">\n                    <value index=\"vDEF\">login</value>\n                </field>\n                <field index=\"settings.redirectFirstMethod\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.redirectPageLogin\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.redirectPageLoginError\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectPageLogout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectDisable\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_messages\">\n            <language index=\"lDEF\">\n                <field index=\"welcome_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"welcome_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"success_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"success_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"error_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"error_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"status_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"status_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"logout_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"logout_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"forgot_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"forgot_reset_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.welcome_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.welcome_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.success_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.success_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.error_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.error_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.status_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.status_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.logout_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.logout_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.forgot_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.forgot_reset_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','','',NULL,124,0,0,0,1,0),(2,'',6,1631521078,1631521078,1,0,0,0,0,'-1',8,0,0,0,0,NULL,0,'a:1:{s:8:\"fe_group\";N;}',0,0,0,0,0,0,0,'header','Willkommen im Virtuellen Kartenforum 2.0','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'3','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,2,0),(4,'',6,1631521078,1631521078,1,0,0,0,0,'-1',256,0,0,0,0,NULL,0,'a:1:{s:8:\"bodytext\";N;}',0,0,0,0,0,0,0,'text','Neu im Virtuellen Kartenforum 2.0?','','<p>Dann melden Sie sich <a href=\"7\">jetzt anmelden</a>!</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'3','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,4,0),(5,'',7,1638199174,1631521078,1,1,0,0,0,'',128,0,0,0,0,NULL,0,'a:1:{s:11:\"pi_flexform\";N;}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','slubwebkartenforum_signup',1,0,'',0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.loginPage\">\n                    <value index=\"vDEF\">6</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','','',NULL,124,0,0,0,5,0),(6,'',9,1631521078,1631521078,1,0,0,0,0,'',32,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'textmedia','Die besten Georeferenzierer','','<p>Die Rangliste gibt eine Übersicht über die Nutzer mit den meisten Georeferenzierungen in unseren Kartensammlungen. Sie unterscheidet zwischen der Erfassung neuer Georeferenzierungen, d.h. die Georeferenzierung von Karten die bis dato unreferenziert waren, und der Aktualisierung bestehender Georeferenzierungen. Aktuell wird jede Georeferenzierung im Kartenforum mit 20 Georeferenzierungspunkten belohnt.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'2','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,6,0),(7,'',9,1637847313,1631521078,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:1:{s:11:\"pi_flexform\";N;}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','slubwebkartenforum_ranking',1,0,'',0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.georefBackend\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','','',NULL,124,0,0,0,7,0),(8,'',9,1631521078,1631521078,1,0,0,0,0,'',64,0,1,6,6,NULL,6,'a:3:{s:11:\"l18n_parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',0,0,0,0,0,0,0,'textmedia','Top Georeferencer','','<p>The following ranking displays the most active users, participating in the georeferencing of our map collections. If differs between the capturing of new georeference parameters, meaning the georeferencing of maps which hadn\'t so far any spatial reference, and the capturing of update georeference parameters, meaning the improvement of already georeference maps. So far the policy of the Virtual Map Forum 2.0 is, that for every capturing process the user receives 20 georeferencing points.</p>\n\n',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'2','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,8,0),(9,'',9,1637847313,1631521078,1,1,0,0,0,'',128,0,1,7,7,NULL,7,'a:4:{s:11:\"l18n_parent\";N;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:11:\"pi_flexform\";s:0:\"\";}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','slubwebkartenforum_ranking',1,0,'',0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.georefBackend\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','','',NULL,124,0,0,0,9,0),(10,'',11,1637771840,1631521078,1,1,0,0,0,'',128,0,0,0,0,NULL,0,'a:25:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','slubwebkartenforum_history',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,10,0),(11,'',7,1638199174,1631521078,1,1,0,0,0,'',256,0,1,5,5,NULL,5,'a:4:{s:11:\"l18n_parent\";N;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:11:\"pi_flexform\";s:349:\"<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.loginPage\">\n                    <value index=\"vDEF\">6</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>\";}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','slubwebkartenforum_signup',1,0,'',0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.loginPage\">\n                    <value index=\"vDEF\">6</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','','',NULL,124,0,0,0,11,0),(12,'',6,1631521078,1631521078,1,0,0,0,0,'-1',16,0,1,2,2,NULL,2,'a:4:{s:8:\"fe_group\";N;s:11:\"l18n_parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',0,0,0,0,0,0,0,'header','Welcome to the Virtual Map Forum 2.0','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'3','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,12,0),(13,'',6,1631521078,1631521078,1,0,0,0,0,'',32,0,1,1,1,NULL,1,'a:4:{s:11:\"l18n_parent\";N;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:11:\"pi_flexform\";s:0:\"\";}',0,0,0,0,0,0,0,'login','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"showForgotPassword\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"showPermaLogin\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"showLogoutFormAfterLogin\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"pages\">\n                    <value index=\"vDEF\">8</value>\n                </field>\n                <field index=\"recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_redirect\">\n            <language index=\"lDEF\">\n                <field index=\"redirectMode\">\n                    <value index=\"vDEF\">login,referer,logout</value>\n                </field>\n                <field index=\"redirectFirstMethod\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"redirectPageLogin\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"redirectPageLoginError\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"redirectPageLogout\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"redirectDisable\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_messages\">\n            <language index=\"lDEF\">\n                <field index=\"welcome_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"welcome_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"success_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"success_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"error_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"error_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"status_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"status_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"logout_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"logout_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"forgot_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"forgot_reset_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','','',NULL,124,0,0,0,13,0),(14,'',6,1631521078,1631521078,1,0,0,0,0,'-1',64,0,1,4,4,NULL,4,'a:5:{s:8:\"fe_group\";N;s:11:\"l18n_parent\";N;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"bodytext\";s:73:\"<p>Dann melden Sie sich <a href=\"t3://page?uid=7\">jetzt anmelden</a>!</p>\";}',0,0,0,0,0,0,0,'text','New to the Virtual Map Forum 2.0?','','<p><a href=\"7\">Register now!</a></p>\n\n',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'3','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,14,0),(15,'',11,1637771840,1631521078,1,1,0,0,0,'',256,0,1,10,10,NULL,10,'a:3:{s:11:\"l18n_parent\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','slubwebkartenforum_history',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,15,0),(16,'',16,1638198953,1631521078,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:25:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','slubwebkartenforum_mapprofile',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,16,0),(17,'',17,1631521078,1631521078,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:1:{s:8:\"bodytext\";N;}',0,0,0,0,0,0,0,'textmedia','','','<h2>Impressum</h2>\n<p>Die nachstehenden Informationen enthalten die gesetzlich vorgesehenen Pflichtangaben zur Anbieterkennzeichnung, sowie wichtige rechtliche Hinweise zur Internetpräsenz der Sächsischen Landesbibliothek - Staats- und Universitätsbibliothek Dresden (SLUB).</p>\n<h3>Anbieter</h3>\n<p>Sächsische Landesbibliothek -<br /> Staats- und Universitätsbibliothek Dresden<br /> Postanschrift: 01054 Dresden<br /> Besucheranschrift: Zellescher Weg 18<br /> 01069 Dresden</p>\n<p>Vertreten durch&nbsp;<strong>Dr. Achim Bonte</strong><br /> Geschäftsstelle<br /> Tel.: +49 351 4677-123<br /> E-Mail:&nbsp;<a href=\"Generaldirektion@slub-dresden.de\">Generaldirektion@slub-dresden.de</a></p>\n<h3>Vertreter</h3>\n<ul> 	<li>Die SLUB ist eine Anstalt öffentlichen Rechts.</li> 	<li>Die SLUB ist die Staatsbibliothek des Freistaates Sachsen und zugleich die Universitätsbibliothek der Technischen Universität Dresden. Sie wird durch den Generaldirektor, Herrn Dr. Achim Bonte, gesetzlich vertreten.</li> 	<li>Der Staatsminister für Wissenschaft und Kunst übt die Dienst- und Fachaufsicht über die Anstalt aus.</li> </ul>\n<h3>Redaktionsverantwortliche</h3>\n<p>N.N.</p>\n<h3>Technische Realisierung</h3>\n<p>N.N.</p>\n<h4>Rechtliche Hinweise zur Haftung</h4>\n<p>Trotz unserer sorgfältigen Bemühungen können wir keine Gewähr für die Richtigkeit, Vollständigkeit und Aktualität unserer Webseiten geben. Weiter übernehmen wir keine Haftung für die Inhalte externer Links. Für den Inhalt der verlinkten Seiten sind ausschließlich deren Betreiber verantwortlich. Die SLUB behält es sich vor, Teile des Internetangebotes oder das gesamte Angebot ohne gesonderte Ankündigung zu ändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,17,0),(18,'',1,1631521494,1631521078,1,1,1,0,0,'',128,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','slubwebkartenforum_mapprofile',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,18,0),(19,'',1,1631521494,1631521078,1,1,0,0,0,'',256,0,1,18,18,NULL,18,'a:3:{s:11:\"l18n_parent\";N;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','slubwebkartenforum_map',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,19,0),(20,'',19,1637841539,1631521078,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:25:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:9:\"list_type\";N;s:5:\"pages\";N;s:9:\"recursive\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','slubwebkartenforum_choosepage',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,20,0),(21,'',20,1637667655,1631521078,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:1:{s:11:\"pi_flexform\";N;}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','slubwebkartenforum_georeference',1,0,'',0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.georefBackend\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','','',NULL,124,0,0,0,21,0),(22,NULL,1,1639733394,1637662837,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'slubwebkartenforum_map','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"xmlTitle\">\n                    <value index=\"vDEF\">Hallo Welt</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0),(23,NULL,20,1637667671,1637667671,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'slubwebkartenforum_georeference','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.georefBackend\">\n                    <value index=\"vDEF\">test</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0),(24,'',5,1637763341,1637763208,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"assets\";N;s:10:\"imagewidth\";N;s:11:\"imageheight\";N;s:11:\"imageborder\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'textmedia','','','<h3>Willkommen im virtuellen Kartenforum</h3>\r\n<p>Das Virtuelle Kartenforum 2.0 wurde 2014 im Rahmen des gleichnamigen DFG Projektes durch die Sächsische Landesbibliothek – Staats- und Universitätsbibliothek Dresden (SLUB) und den Lehrstuhl für Geodäsie und Geoinformatik der Universität Rostock entwickelt. Es bietet einen Zugriff auf große Teile der historischen Kartensammlung der SLUB und ermöglicht den Nutzern die Georeferenzierung der Historischen Karten.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(25,NULL,5,1637763627,1637763461,1,0,0,0,0,'',512,0,0,0,0,NULL,0,'a:7:{s:5:\"CType\";N;s:6:\"colPos\";N;s:11:\"pi_flexform\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;}',0,0,0,0,0,0,0,'slubwebkartenforum_apps','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.importApp\">\n                    <value index=\"vDEF\">ProgressBar</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0),(26,NULL,11,1637771852,1637771852,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'slubwebkartenforum_apps','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.importApp\">\n                    <value index=\"vDEF\">UserHistory</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0),(27,NULL,19,1637841547,1637841547,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'slubwebkartenforum_apps','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.importApp\">\n                    <value index=\"vDEF\">UnreferencedMaps</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0),(28,NULL,9,1637847323,1637847323,1,0,0,0,0,'',48,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'slubwebkartenforum_apps','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.importApp\">\n                    <value index=\"vDEF\">GeoreferenceRanking</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0),(29,NULL,28,1639738127,1637850062,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:7:{s:5:\"CType\";N;s:6:\"colPos\";N;s:11:\"pi_flexform\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;}',0,0,0,0,0,0,0,'slubwebkartenforum_apps','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.importApp\">\n                    <value index=\"vDEF\">EvaluationTool</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0),(30,NULL,7,1641559331,1638199226,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:7:{s:5:\"CType\";N;s:6:\"colPos\";N;s:11:\"pi_flexform\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;}',0,0,0,0,0,0,0,'slubwebkartenforum_signup','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.loginPage\">\n                    <value index=\"vDEF\">6</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0),(31,NULL,28,1639738115,1639738115,1,0,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'slubwebkartenforum_admin','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"xmlTitle\">\n                    <value index=\"vDEF\">Evaluation</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `repository` int(10) unsigned NOT NULL DEFAULT 1,
  `version` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ownerusername` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `md5hash` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `update_comment` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `authorcompany` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`repository`),
  KEY `index_extrepo` (`extension_key`,`repository`),
  KEY `index_versionrepo` (`integer_version`,`repository`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_repository`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_repository` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `wsdl_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mirror_list_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_update` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_count` int(11) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_repository`
--

LOCK TABLES `tx_extensionmanager_domain_model_repository` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-07 13:32:41
